import os
import pandas as pd
import numpy as np
from scipy.stats import wilcoxon

BASE_DIR = r"D:\always\Desktop\对比实验\固定时间\固定"

files = {
    "Ring_PPO_PSO": os.path.join(BASE_DIR, "Ring_PPO_PSO_results.xlsx"),
    "PPO":          os.path.join(BASE_DIR, "PPO_results.xlsx"),
    "Q_learning":   os.path.join(BASE_DIR, "Q_learning_results.xlsx"),
    "DERL":         os.path.join(BASE_DIR, "DERL_results.xlsx"),
    "DQN":          os.path.join(BASE_DIR, "DQN_results.xlsx"),
    "AHDPSO":       os.path.join(BASE_DIR, "AHDPSO_results.xlsx"),
    "AFMPSO":       os.path.join(BASE_DIR, "AFMPSO_results.xlsx"),
    "APSO":         os.path.join(BASE_DIR, "APSO_results.xlsx"),
    "MPSO":         os.path.join(BASE_DIR, "MPSO_results.xlsx"),
    "PSO":          os.path.join(BASE_DIR, "PSO_results.xlsx"),
    "SDPSO":        os.path.join(BASE_DIR, "SDPSO_results.xlsx"),
}

baseline_name = "Ring_PPO_PSO"  # 作为 Wilcoxon 检验的基准

TC_CANDIDATES = ["Total Coverage", "f1 (Global Coverage)", "Area Coverage", "Global Coverage", "f1"]
UC_CANDIDATES = ["User Coverage", "f2 (User Coverage)", "f2"]
GASU_CANDIDATES = ["Special Area Signal Uniformity", "f3 (Uniformity)", "Uniformity", "f3"]
FIT_CANDIDATES = ["Fitness", "fitness", "Objective", "objective"]

def pick_column(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None

data = {}
for name, path in files.items():
    if not os.path.exists(path):
        print(f"[跳过] 找不到文件: {path}")
        continue
    df = pd.read_excel(path)
    
    tc_col = pick_column(df, TC_CANDIDATES)
    uc_col = pick_column(df, UC_CANDIDATES)
    gasu_col = pick_column(df, GASU_CANDIDATES)
    fit_col = pick_column(df, FIT_CANDIDATES)

    if tc_col is None or uc_col is None:
        print(f"[跳过] {name} 缺少 TC 或 UC 列")
        continue

    data[name] = {
        "TC":   df[tc_col].dropna().values.astype(float),
        "UC":   df[uc_col].dropna().values.astype(float),
        "GASU": df[gasu_col].dropna().values.astype(float) if gasu_col else np.array([]),
        "Fitness": df[fit_col].dropna().values.astype(float) if fit_col else np.array([]),
    }

if baseline_name not in data:
    print(f"[ERROR] 基准算法 {baseline_name} 数据缺失。")
    raise SystemExit(1)

base_means = {k: np.mean(v) for k, v in data[baseline_name].items()}


def wilcoxon_flag(sample, baseline, sample_mean, baseline_mean):
    n = min(len(sample), len(baseline))
    if n < 2:
        return "="
    try:
        _, p = wilcoxon(sample[:n], baseline[:n])
    except ValueError:
        return "="
    
    if p < 0.05:
        return "-" if sample_mean > baseline_mean else "+"
    return "="

metrics = ["TC", "UC", "GASU", "Fitness", "Wilcoxon"]
table_rows = []

for metric in metrics:
    row = {"Metric": metric}
  
    for algo in files:
        if algo not in data:
            row[algo] = np.nan
            continue
            
        if metric == "Wilcoxon":
            if algo == baseline_name:
                row[algo] = "/"
            else:
                flag = wilcoxon_flag(data[algo]["TC"], data[baseline_name]["TC"], 
                                     np.mean(data[algo]["TC"]), base_means["TC"])
                row[algo] = flag
        else:
            val = np.mean(data[algo][metric]) if len(data[algo][metric]) > 0 else np.nan
            
            if metric in ["TC", "UC"]:
                row[algo] = f"{val:.2%}" 
            else:
                row[algo] = f"{val:.4f}"  
                
    table_rows.append(row)

table = pd.DataFrame(table_rows)


UAV_NUM = 20
USER_NUM = 100

table.insert(0, "UAVs", UAV_NUM) 
table.insert(1, "Users", USER_NUM) 

table["UAVs"] = table["UAVs"].astype(object)
table["Users"] = table["Users"].astype(object)
for i in range(1, len(table)):
    table.loc[i, "UAVs"] = ""
    table.loc[i, "Users"] = ""

cols = ["UAVs", "Users", "Metric"] + [c for c in table.columns if c not in ["UAVs", "Users", "Metric"]]
table = table[cols]

print("\n" + "=" * 80)
print(f"Results for {UAV_NUM} UAVs and {USER_NUM} Users")
print("=" * 80)

print(table.to_string(index=False))

out_path = os.path.join(BASE_DIR, "Horizontal_Results_Table.xlsx")
table.to_excel(out_path, index=False)
print(f"\n已保存 -> {out_path}")