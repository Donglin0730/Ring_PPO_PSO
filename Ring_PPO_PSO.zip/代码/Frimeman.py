import os
import pandas as pd
import numpy as np
from scipy.stats import friedmanchisquare, rankdata

BASE_DIR = r"D:\always\Desktop\对比实验\25UAV 70users\固定"

files = {
    "AHDPSO":       os.path.join(BASE_DIR, "AHDPSO_results.xlsx"),
    "AFMPSO":       os.path.join(BASE_DIR, "AFMPSO_results.xlsx"),
    "APSO":       os.path.join(BASE_DIR,   "APSO_results.xlsx"),
    "DERL":         os.path.join(BASE_DIR, "DERL_results.xlsx"),
    "DQN":          os.path.join(BASE_DIR, "DQN_results.xlsx"),
    "MPSO":         os.path.join(BASE_DIR, "MPSO_results.xlsx"),
    "PPO":          os.path.join(BASE_DIR, "PPO_results.xlsx"),
    "PSO":          os.path.join(BASE_DIR, "PSO_results.xlsx"),
    "Q_learning":   os.path.join(BASE_DIR, "Q_learning_results.xlsx"),
    "SDPSO":         os.path.join(BASE_DIR, "SDPSO_results.xlsx"),
    "Ring_PPO_PSO": os.path.join(BASE_DIR, "Ring_PPO_PSO_results.xlsx"),
}

FIT_CANDIDATES = ["Fitness", "fitness", "Objective", "objective"]


def pick_column(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


data = {}
for name, path in files.items():
    if not os.path.exists(path):
        print(f"[跳过] {path} 不存在")
        continue

    df = pd.read_excel(path)
    fit_col = pick_column(df, FIT_CANDIDATES)
    if fit_col is None:
        print(f"[跳过] {name}: 未找到 Fitness 列")
        continue

    data[name] = df[fit_col].dropna().values.astype(float)

if not data:
    raise SystemExit("没有读取到任何有效数据，请检查路径。")

n = min(len(v) for v in data.values())
print(f"每个算法取前 {n} 次运行用于 Friedman Test\n")

algorithms = list(data.keys())
matrix = np.array([data[a][:n] for a in algorithms])   # (k, n)

stat, p = friedmanchisquare(*matrix)

print("=" * 60)
print("Friedman Test (Fitness 越大越好)")
print("=" * 60)
print(f"算法数量 k = {len(algorithms)}")
print(f"运行次数 n = {n}")
print(f"Friedman statistic = {stat:.4f}")
print(f"p-value            = {p:.6f}")

if p < 0.05:
    print("结论：算法之间存在显著差异（p < 0.05）")
else:
    print("结论：算法之间无显著差异（p >= 0.05）")


ranks = np.array([rankdata(-matrix[:, j]) for j in range(n)])
mean_ranks = ranks.mean(axis=0)

rank_table = pd.DataFrame({
    "Algorithm": algorithms,
    "Mean Rank": mean_ranks,
}).sort_values("Mean Rank").reset_index(drop=True)

rank_table["Rank"] = range(1, len(rank_table) + 1)

print("\n" + "=" * 60)
print("Average Ranks (越小越好) + Rank")
print("=" * 60)
print(rank_table.to_string(index=False, float_format=lambda x: f"{x:.4f}"))

out_path = os.path.join(BASE_DIR, "Friedman_Test.xlsx")
try:
    rank_table.to_excel(out_path, index=False)
    print(f"\n已保存 -> {out_path}")
except PermissionError:
    alt = os.path.join(BASE_DIR, "Friedman_Test_new.xlsx")
    rank_table.to_excel(alt, index=False)
    print(f"\n原文件被占用，已保存到 -> {alt}")