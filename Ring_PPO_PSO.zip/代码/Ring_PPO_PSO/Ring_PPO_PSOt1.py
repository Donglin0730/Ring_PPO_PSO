import os
os.environ["OMP_NUM_THREADS"] = "8"
os.environ["MKL_NUM_THREADS"] = "8"
import time
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
torch.set_num_threads(8)
import gymnasium as gym
from gymnasium import spaces
from scipy.stats import qmc

from model import (canshu, init_base_station, init_users,
                   update_coverage, user_coverage,
                   calculate_uniformity, objective_function,
                   NOISE_DBM)

# 强化学习环境
class DeploymentEnv(gym.Env):
    def __init__(self, size=50, num_uav=25, num_users=70, grid_res=6,
                 height_levels=(400, 450, 500)):
        self.size, self.num_uav, self.grid_res = size, num_uav, grid_res
        self.num_users = num_users
        self.height_levels = list(height_levels)
        self.n_pos, self.n_height = grid_res * grid_res, len(self.height_levels)
      
        self.rng = np.random.RandomState()

        self.action_space = spaces.Discrete(self.n_pos * self.n_height)
        self.observation_space = spaces.Box(
            low=-1, high=1, shape=(num_uav * 3 + 4,), dtype=np.float32)

        self.users = []
        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_slots = set()
        self.grid = np.full((size, size), NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((size, size), dtype=int)
        self.prev_fitness = 0.0

    # 网格索引转二维坐标
    def _cell_to_xy(self, cell_idx):
        i, j = cell_idx // self.grid_res, cell_idx % self.grid_res
        return ((i + 0.5) / self.grid_res * self.size,
                (j + 0.5) / self.grid_res * self.size)

    # 二维坐标转网格索引
    def _xy_to_cell(self, x, y):
        i = int(np.clip(x / self.size * self.grid_res, 0, self.grid_res - 1))
        j = int(np.clip(y / self.size * self.grid_res, 0, self.grid_res - 1))
        return i * self.grid_res + j

    # 计算覆盖率
    def _cov(self):
        if not self.base_stations:
            self.grid.fill(NOISE_DBM)
            self.coverage_grid.fill(0)
            return 0.0, 0.0
        ucov = user_coverage(self.users, self.base_stations)
        update_coverage(self.grid, self.coverage_grid,
                        self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))
        return ucov, acov

    # 构建状态向量
    def _state(self):
        s = np.zeros(self.num_uav * 3, dtype=np.float32)
        n = min(len(self.uav_positions), self.num_uav)
        for k in range(n):
            p = self.uav_positions[k]
            h = self.uav_heights[k]
            s[k * 3] = p[0] / self.size
            s[k * 3 + 1] = p[1] / self.size
            s[k * 3 + 2] = h / 500.0

        ucov, acov = self._cov()
        if self.base_stations:
            f3 = calculate_uniformity(self.size, self.grid)
        else:
            f3 = 0.0

        return np.concatenate([
            s,
            [len(self.uav_positions) / self.num_uav, ucov, acov, f3]
        ]).astype(np.float32)

    # 重置环境
    def reset(self, seed=None, options=None):
        if not self.users:
            self.users = init_users(
                num_users=self.num_users,
                size=self.size,
                radius_range=(15, 25),
                speed_range=(1, 3),
                seed=None
            )

        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_slots = set()
        self.grid = np.full((self.size, self.size), NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)
        self.prev_fitness = 0.0

        return self._state(), {}

    # 从 PSO 最优解预加载部分 UAV
    def preload_from_solution(self, Xgbest, users=None, keep_ratio=0.6,
                              snap_to_cell=False):
        if users is not None:
            self.users = users

        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_slots = set()
        self.grid = np.full((self.size, self.size), NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)
        self.prev_fitness = 0.0

        num_preload = int(self.num_uav * keep_ratio)
        deployed_slots = set()
        count = 0

        for j in range(self.num_uav):
            if count >= num_preload:
                break
            x_ = float(Xgbest[j, 0])
            y_ = float(Xgbest[j, 1])
            h_ = float(Xgbest[j, 2])

            pos_idx = self._xy_to_cell(x_, y_)
            h_idx = int(np.argmin([abs(h_ - hl) for hl in self.height_levels]))
            slot = (pos_idx, h_idx)

            if slot in deployed_slots:
                continue
            deployed_slots.add(slot)

            if snap_to_cell:
                xc, yc = self._cell_to_xy(pos_idx)
            else:
                xc, yc = x_, y_

            bs = init_base_station(h_, (xc, yc))
            self.base_stations.append(bs)
            self.uav_positions.append((xc, yc))
            self.uav_heights.append(h_)
            self.occupied_slots.add(slot)
            count += 1

        while count < num_preload:
            pos_idx = self.rng.randint(0, self.n_pos)
            h_idx = self.rng.randint(0, self.n_height)
            slot = (pos_idx, h_idx)
            if slot in deployed_slots:
                continue
            xc, yc = self._cell_to_xy(pos_idx)
            h_ = self.height_levels[h_idx]
            bs = init_base_station(h_, (xc, yc))
            self.base_stations.append(bs)
            self.uav_positions.append((xc, yc))
            self.uav_heights.append(h_)
            self.occupied_slots.add(slot)
            deployed_slots.add(slot)
            count += 1

        if self.base_stations:
            self._cov()
            self.prev_fitness = objective_function(
                self.size, self.grid, self.coverage_grid,
                self.users, self.base_stations)

        return self._state()

    # 有效动作掩码
    def get_valid_action_mask(self):
        mask = np.ones(self.action_space.n, dtype=bool)
        for c, h_idx in self.occupied_slots:
            mask[c * self.n_height + h_idx] = False
        return mask

    # 执行动作
    def step(self, action):
        if len(self.uav_positions) >= self.num_uav:
            return self._state(), 0.0, True, False, {'ucov': 0.0, 'acov': 0.0}

        pos_idx = int(action) // self.n_height
        h_idx = int(action) % self.n_height
        slot = (pos_idx, h_idx)
        if slot in self.occupied_slots:
            return self._state(), -1.0, False, False, {'ucov': 0.0, 'acov': 0.0}

        x, y = self._cell_to_xy(pos_idx)
        h = self.height_levels[h_idx]
        self.base_stations.append(init_base_station(h, (x, y)))
        self.uav_positions.append((x, y))
        self.uav_heights.append(h)
        self.occupied_slots.add(slot)

        ucov, acov = self._cov()

        cur_fitness = objective_function(
            self.size, self.grid, self.coverage_grid,
            self.users, self.base_stations)
        r = (cur_fitness - self.prev_fitness) + 0.3 * cur_fitness
        self.prev_fitness = cur_fitness

        done = len(self.uav_positions) >= self.num_uav
        if done:
            r += cur_fitness * 0.5

        return self._state(), r, done, False, {'ucov': ucov, 'acov': acov}


# Actor-Critic 网络
class ActorCritic(nn.Module):
    def __init__(self, s, a, hidden=128):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(s, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU()
        )
        self.actor = nn.Linear(hidden, a)
        self.critic = nn.Linear(hidden, 1)

    def forward(self, x):
        f = self.shared(x)
        return self.actor(f), self.critic(f)


# PPO 智能体
class PPOAgent:
    def __init__(self, s, a, hidden=128, lr=1e-4, gamma=0.99, lam=0.95,
                 clip=0.2, epochs=10, batch_size=25, entropy_coef=0.05):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.net = ActorCritic(s, a, hidden).to(self.device)
        self.opt = optim.Adam(self.net.parameters(), lr=lr)
        self.gamma, self.lam, self.clip = gamma, lam, clip
        self.epochs, self.batch_size = epochs, batch_size
        self.entropy_coef = entropy_coef
        self.buffer_s, self.buffer_a, self.buffer_lp = [], [], []
        self.buffer_r, self.buffer_v, self.buffer_d = [], [], []

    # 选择动作
    def act(self, s, valid_mask=None):
        with torch.no_grad():
            t = torch.FloatTensor(s).unsqueeze(0).to(self.device)
            logits, v = self.net(t)
            if valid_mask is not None:
                logits[0, ~torch.BoolTensor(valid_mask).to(self.device)] = -1e9
            dist = torch.distributions.Categorical(logits=logits)
            a = dist.sample()
            lp = dist.log_prob(a).sum()
        return int(a.item()), lp.item(), v.item()

    # 存储经验
    def store(self, s, a, lp, r, v, d):
        self.buffer_s.append(s); self.buffer_a.append(a); self.buffer_lp.append(lp)
        self.buffer_r.append(r); self.buffer_v.append(v); self.buffer_d.append(d)

    # 清空缓存
    def clear(self):
        self.buffer_s, self.buffer_a, self.buffer_lp = [], [], []
        self.buffer_r, self.buffer_v, self.buffer_d = [], [], []

    # 计算 GAE
    def _gae(self, last_v):
        T = len(self.buffer_r)
        adv = np.zeros(T, dtype=np.float32)
        ret = np.zeros(T, dtype=np.float32)
        g = 0.0
        for t in reversed(range(T)):
            next_v = last_v if t == T - 1 else self.buffer_v[t + 1]
            non_term = 1.0 - self.buffer_d[t]
            delta = self.buffer_r[t] + self.gamma * next_v * non_term - self.buffer_v[t]
            g = delta + self.gamma * self.lam * non_term * g
            adv[t] = g; ret[t] = g + self.buffer_v[t]
        return adv, ret

    # 更新网络
    def update(self, last_v):
        if len(self.buffer_r) == 0:
            return
        adv, ret = self._gae(last_v)
        S = torch.FloatTensor(np.array(self.buffer_s)).to(self.device)
        A = torch.LongTensor(np.array(self.buffer_a)).to(self.device)
        LP = torch.FloatTensor(np.array(self.buffer_lp)).to(self.device)
        ADV = torch.FloatTensor(adv).to(self.device)
        RET = torch.FloatTensor(ret).to(self.device)
        ADV = (ADV - ADV.mean()) / (ADV.std() + 1e-8)
        T = len(S)
        for _ in range(self.epochs):
            idx = np.random.permutation(T)
            for i in range(0, T, self.batch_size):
                b = idx[i:i + self.batch_size]
                logits, values = self.net(S[b])
                dist = torch.distributions.Categorical(logits=logits)
                new_lp = dist.log_prob(A[b])
                entropy = dist.entropy().mean()
                ratio = torch.exp(new_lp - LP[b])
                surr1 = ratio * ADV[b]
                surr2 = torch.clamp(ratio, 1.0 - self.clip, 1.0 + self.clip) * ADV[b]
                actor_loss = -torch.min(surr1, surr2).mean()
                critic_loss = nn.MSELoss()(values.squeeze(-1), RET[b])
                loss = actor_loss + 0.5 * critic_loss - self.entropy_coef * entropy
                self.opt.zero_grad(); loss.backward()
                torch.nn.utils.clip_grad_norm_(self.net.parameters(), 0.5)
                self.opt.step()

    # 加载模型
    def load(self, path):
        try:
            state = torch.load(path, map_location=self.device)
            key = 'shared.0.weight'
            if key in state and state[key].shape[1] != self.net.shared[0].weight.shape[1]:
                print(f"[PPOAgent.load] Dimension mismatch, skipping load, using random weights.")
                return False
            self.net.load_state_dict(state)
            return True
        except Exception as e:
            print(f"[PPOAgent.load] Load failed: {e}")
            return False


# 环形 PSO
class RingPSO:
    def __init__(self, num_particles=60, num_bs=25, size=50, users=None):
        self.N, self.num_bs, self.size = num_particles, num_bs, size
        self.users = users
        self.X = np.zeros((self.N, self.num_bs, 3))
        sampler = qmc.LatinHypercube(d=self.num_bs * 2)
        samples = sampler.random(n=self.N)
        self.X[:, :, 0] = samples[:, 0::2] * (size - 1)
        self.X[:, :, 1] = samples[:, 1::2] * (size - 1)

        sampler_h = qmc.LatinHypercube(d=self.num_bs)
        samples_h = sampler_h.random(n=self.N)
        self.X[:, :, 2] = 400 + samples_h * 100

        self.V = np.zeros_like(self.X)
        self.Pbest, self.fpbest = self.X.copy(), np.full(self.N, -np.inf)
        self.Xgbest, self.fgbest = self.X[0].copy(), -np.inf

    # 评估适应度
    def _eval(self, X):
        N, B, _ = X.shape
        fitness = np.zeros(N)
        for i in range(N):
            bs_list = [
                init_base_station(float(X[i, j, 2]),
                                  (float(X[i, j, 0]), float(X[i, j, 1])))
                for j in range(B)
            ]
            grid_tmp = np.full((self.size, self.size), NOISE_DBM, dtype=float)
            cov_tmp = np.zeros((self.size, self.size), dtype=int)
            update_coverage(grid_tmp, cov_tmp, bs_list, self.size)
            fitness[i] = objective_function(
                self.size, grid_tmp, cov_tmp, self.users, bs_list
            )
        return fitness

    # PSO 单步更新
    def step_once(self, progress):
        ratio = min(1.0, max(0.0, progress))
        w = 0.9 - 0.4 * ratio
        c1 = 2.0 - 1.6 * ratio
        c2 = 0.4 + 1.6 * ratio

        f_left, f_right = np.roll(self.fpbest, 1), np.roll(self.fpbest, -1)
        p_left, p_right = np.roll(self.Pbest, 1, axis=0), np.roll(self.Pbest, -1, axis=0)
        best = np.argmax(np.stack([self.fpbest, f_left, f_right]), axis=0)
        Lb = np.stack([self.Pbest, p_left, p_right])[best, np.arange(self.N), :]

        self.V = (w * self.V
                  + c1 * np.random.rand(self.N, 1, 1) * (self.Pbest - self.X)
                  + c2 * np.random.rand(self.N, 1, 1) * (self.Xgbest[None] - self.X)
                  + c1 * np.random.rand(self.N, 1, 1) * (Lb - self.X))
        self.X = np.clip(self.X + self.V, [0, 0, 400],
                         [self.size - 1, self.size - 1, 500])

        f = self._eval(self.X)
        improve = f > self.fpbest
        self.fpbest[improve], self.Pbest[improve] = f[improve], self.X[improve]
        idx = np.argmax(self.fpbest)
        if self.fpbest[idx] > self.fgbest:
            self.fgbest, self.Xgbest = self.fpbest[idx], self.Pbest[idx].copy()

    # PPO 单步更新
    def step_ppo(self, t, agent, env):
        for i in range(self.N):
            env.reset(seed=None)
            env.users = self.users
            keep_ratio = 0.6
            env.preload_from_solution(self.Xgbest, users=self.users,
                                      keep_ratio=keep_ratio, snap_to_cell=False)
            num_remaining = self.num_bs - len(env.base_stations)
            s = env._state()
            for _ in range(num_remaining):
                valid_mask = env.get_valid_action_mask()
                if not valid_mask.any():
                    break
                a, _, _ = agent.act(s, valid_mask)
                ns, _, done, _, _ = env.step(a)
                s = ns
                if done:
                    break
            for k in range(min(self.num_bs, len(env.uav_positions))):
                self.X[i, k, 0] = env.uav_positions[k][0]
                self.X[i, k, 1] = env.uav_positions[k][1]
                self.X[i, k, 2] = env.uav_heights[k]

        f = self._eval(self.X)
        improve = f > self.fpbest
        self.fpbest[improve], self.Pbest[improve] = f[improve], self.X[improve]
        idx = np.argmax(self.fpbest)
        if self.fpbest[idx] > self.fgbest:
            self.fgbest, self.Xgbest = self.fpbest[idx], self.Pbest[idx].copy()


# 混合训练
def train_hybrid(max_runtime_seconds=300, size=50, num_uav=25, num_users=50,
                 verbose=True, ppo_model_path="ppo_pretrained.pth", record_interval=10):
    # 用户随机生成
    users = init_users(
        num_users=num_users,
        size=size,
        radius_range=(15, 25),
        speed_range=(1, 3),
        seed=None
    )

    pso = RingPSO(num_particles=60, num_bs=num_uav, size=size, users=None)
    pso.users = users
    env = DeploymentEnv(size=size, num_uav=num_uav, num_users=num_users)
    env.users = users

    agent = PPOAgent(env.observation_space.shape[0], env.action_space.n)
    if os.path.exists(ppo_model_path):
        ok = agent.load(ppo_model_path)
        if verbose and ok:
            print(f"[Init] Loaded pretrained PPO from {ppo_model_path}")
    elif verbose:
        print(f"[Init] WARNING: {ppo_model_path} not found. Using random PPO.")

    mode = "PSO"
    ppo_run_time = 0.0
    stagnation_time = 0.0

    fitness_history = {}
    next_target_time = record_interval

    t = 0
    prev_fgbest = None
    start_time = time.time()

    # 动态阈值区间
    stag_min_sec = 60
    stag_max_sec = 120
    ppo_no_improve_limit = 30

    last_time = start_time

    while time.time() - start_time < max_runtime_seconds:
        current_time = time.time()
        elapsed_time = current_time - start_time
        dt = current_time - last_time
        last_time = current_time

        progress = elapsed_time / max_runtime_seconds

        # 动态阈值
        current_stag_threshold = stag_min_sec + (stag_max_sec - stag_min_sec) * progress
        current_ppo_max_seconds = 150 - 50 * progress

        # 按时间间隔记录
        while elapsed_time >= next_target_time and next_target_time <= max_runtime_seconds:
            fitness_history[f"time_{next_target_time}"] = pso.fgbest
            if verbose:
                print(f"[{next_target_time:4d}s] Current mode: {mode:4s} | fgbest = {pso.fgbest:.6f}")
            next_target_time += record_interval

        # 计算停滞时间
        if prev_fgbest is None or not np.isfinite(prev_fgbest):
            improvement = 0.0
        else:
            improvement = pso.fgbest - prev_fgbest

        if improvement < 1e-6:
            stagnation_time += dt
        else:
            stagnation_time = 0.0

        # PSO -> PPO 切换
        if mode == "PSO":
            if stagnation_time >= current_stag_threshold and elapsed_time >= max_runtime_seconds * 0.2:
                if verbose:
                    print(f"  >> [Switch] {elapsed_time:.1f}s: PSO -> PPO "
                          f"(dynamic threshold:{current_stag_threshold:.1f}s, actual stagnation {stagnation_time:.1f}s)")
                mode = "PPO"
                ppo_run_time = 0.0
                stagnation_time = 0.0
                ppo_best_fgbest = pso.fgbest
                ppo_no_improve_time = 0.0
        # PPO -> PSO 切换
        else:
            ppo_run_time += dt
            if pso.fgbest > ppo_best_fgbest + 1e-6:
                ppo_best_fgbest = pso.fgbest
                ppo_no_improve_time = 0.0
            else:
                ppo_no_improve_time += dt

            if ppo_run_time >= current_ppo_max_seconds or ppo_no_improve_time >= ppo_no_improve_limit:
                if verbose:
                    print(f"  >> [Switch] {elapsed_time:.1f}s: PPO -> PSO "
                          f"(dynamic limit:{current_ppo_max_seconds:.1f}s)")
                mode = "PSO"
                ppo_run_time = 0.0

        if mode == "PSO":
            pso.step_once(progress)
        else:
            pso.step_ppo(t, agent, env)

        prev_fgbest = pso.fgbest
        t += 1

    total_time = time.time() - start_time
    return (env, pso, fitness_history, total_time)


if __name__ == "__main__":
    p = canshu()
    NUM_RUNS = 20
    MAX_RUNTIME_SECONDS = 500
    RECORD_INTERVAL = 10

    fixed_time_columns = [f"time_{j}" for j in range(RECORD_INTERVAL, MAX_RUNTIME_SECONDS + 1, RECORD_INTERVAL)]

    current_dir = os.path.dirname(os.path.abspath(__file__))
    all_results = []

    ppo_model_path = os.path.join(current_dir, "ppo_pretrained.pth")
    print(f"PPO model path: {ppo_model_path}")
    print(f"Model exists: {os.path.exists(ppo_model_path)}")

    for i in range(NUM_RUNS):
        print(f"\n--- Run {i + 1} / {NUM_RUNS} (Time limit: {MAX_RUNTIME_SECONDS}s) ---")

        (env, pso, fitness_history, dt) = train_hybrid(
            max_runtime_seconds=MAX_RUNTIME_SECONDS, size=p['size'],
            num_uav=p['num_base_stations'], num_users=p['num_users'],
            verbose=True,
            ppo_model_path=ppo_model_path,
            record_interval=RECORD_INTERVAL)

        total_time = dt

        # 计算最终指标
        bs_list = [
            init_base_station(pso.Xgbest[j, 2],
                              (pso.Xgbest[j, 0], pso.Xgbest[j, 1]))
            for j in range(p['num_base_stations'])
        ]
        grid_tmp = np.full((p['size'], p['size']), NOISE_DBM, dtype=float)
        cov_tmp = np.zeros((p['size'], p['size']), dtype=int)
        update_coverage(grid_tmp, cov_tmp, bs_list, p['size'])

        final_f1 = float(np.mean(cov_tmp))
        final_f2 = user_coverage(env.users, bs_list)
        final_f3 = calculate_uniformity(p['size'], grid_tmp)
        final_obj = objective_function(p['size'], grid_tmp, cov_tmp,
                                       env.users, bs_list)

        print(f"  >> Run {i + 1} Final: f1={final_f1:.2%}, f2={final_f2:.2%}, "
              f"f3={final_f3:.4f}, Fitness={final_obj:.4f}")

        result = {
            'Run': i + 1,
            'f1 (Global Coverage)': final_f1,
            'f2 (User Coverage)': final_f2,
            'f3 (Uniformity)': final_f3,
            'Fitness': final_obj,
            'Time (s)': total_time,
            'Base Station Positions': ";".join([
                f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
                for bs in bs_list]),
        }

        for col in fixed_time_columns:
            result[col] = fitness_history.get(col, final_obj)

        all_results.append(result)

        excel_path = os.path.join(current_dir, "Ring_PPO_PSO_results.xlsx")
        try:
            pd.DataFrame(all_results).to_excel(excel_path, index=False)
        except Exception as e:
            print(f"Failed to save Excel: {e}")
            print("Please check if the file is currently open in Excel or WPS and close it before rerunning.")

    print(f"\nAll runs completed! Excel saved to: {excel_path}")