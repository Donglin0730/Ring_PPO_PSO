import os
os.environ["OMP_NUM_THREADS"] = "8"
os.environ["MKL_NUM_THREADS"] = "8"
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
torch.set_num_threads(8)
import gymnasium as gym
from gymnasium import spaces
import model

# 部署环境
class DeploymentEnv(gym.Env):
    def __init__(self, size=50, num_uav=20, num_users=70, grid_res=6,
                 height_levels=(400, 450, 500)):
        self.size, self.num_uav, self.grid_res = size, num_uav, grid_res
        self.num_users = num_users
        self.height_levels = list(height_levels)
        self.n_pos, self.n_height = grid_res * grid_res, len(self.height_levels)
        self.rng = np.random.RandomState()

        self.action_space = spaces.Discrete(self.n_pos * self.n_height)
      
        self.observation_space = spaces.Box(
            low=-1, high=1, shape=(num_uav * 3 + 4,), dtype=np.float32)

        self.users = []
        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_cells = set()
        self.grid = np.zeros((size, size))
        self.coverage_grid = np.zeros((size, size), dtype=int)

    # 网格索引转二维坐标
    def _cell_to_xy(self, cell_idx):
        i, j = cell_idx // self.grid_res, cell_idx % self.grid_res
        return ((i + 0.5) / self.grid_res * self.size,
                (j + 0.5) / self.grid_res * self.size)

    # 二维坐标转网格索引
    def _xy_to_cell(self, x, y):
        i = int(np.clip(x / self.size * self.grid_res, 0, self.grid_res - 1))
        j = int(np.clip(y / self.size * self.grid_res, 0, self.grid_res - 1))
        return i * self.grid_res + j

    # 计算 ucov, acov 并写回网格
    def _cov(self):
        if not self.base_stations:
            self.grid.fill(0.0)
            self.coverage_grid.fill(0)
            return 0.0, 0.0

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))
        return ucov, acov

    # 构建状态向量
    def _state(self):
        s = np.zeros(self.num_uav * 3, dtype=np.float32)
        n = min(len(self.uav_positions), self.num_uav)
        for k in range(n):
            p = self.uav_positions[k]
            h = self.uav_heights[k]
            s[k * 3] = p[0] / self.size
            s[k * 3 + 1] = p[1] / self.size
            s[k * 3 + 2] = h / 500.0

        ucov, acov = self._cov()

        if self.base_stations:
            uall = model.calculate_uniformity(self.size, self.grid)
        else:
            uall = 0.0

        return np.concatenate([s, [len(self.uav_positions) / self.num_uav,
                                   ucov, acov, uall]]).astype(np.float32)

    # 重置环境
    def reset(self, seed=None, options=None):
        p = model.canshu()
        self.users = model.init_users(
            self.num_users, self.size,
            radius_range=p['user_radius_range'],
            speed_range=p['user_speed_range'],
            seed=None)

        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_cells = set()
        self.grid = np.zeros((self.size, self.size))
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)

        return self._state(), {}

    # 从 PSO 最优解预加载部分 UAV
    def preload_from_solution(self, Xgbest, users=None, keep_ratio=0.6):
        if users is not None:
            self.users = users

        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_cells = set()
        self.grid = np.zeros((self.size, self.size))
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)

        num_preload = int(self.num_uav * keep_ratio)
        deployed_cells = set()
        count = 0

        for j in range(self.num_uav):
            if count >= num_preload:
                break
            x_ = float(Xgbest[j, 0])
            y_ = float(Xgbest[j, 1])
            h_ = float(Xgbest[j, 2])

            pos_idx = self._xy_to_cell(x_, y_)
            if pos_idx in deployed_cells:
                continue

            xc, yc = self._cell_to_xy(pos_idx)
            bs = model.init_base_station(h_, (xc, yc))
            self.base_stations.append(bs)
            self.uav_positions.append((xc, yc))
            self.uav_heights.append(h_)
            self.occupied_cells.add(pos_idx)
            deployed_cells.add(pos_idx)
            count += 1

        while count < num_preload:
            pos_idx = self.rng.randint(0, self.n_pos)
            if pos_idx in deployed_cells:
                continue
            xc, yc = self._cell_to_xy(pos_idx)
            h_ = self.rng.uniform(400, 500)
            bs = model.init_base_station(h_, (xc, yc))
            self.base_stations.append(bs)
            self.uav_positions.append((xc, yc))
            self.uav_heights.append(h_)
            self.occupied_cells.add(pos_idx)
            deployed_cells.add(pos_idx)
            count += 1

        return self._state()

    # 有效动作掩码
    def get_valid_action_mask(self):
        mask = np.ones(self.action_space.n, dtype=bool)
        for c in self.occupied_cells:
            for h_idx in range(self.n_height):
                mask[c * self.n_height + h_idx] = False
        return mask

    # 执行动作
    def step(self, action):
        if len(self.uav_positions) >= self.num_uav:
            return self._state(), 0.0, True, False, {'ucov': 0.0, 'acov': 0.0}

        pos_idx = int(action) // self.n_height
        h_idx = int(action) % self.n_height
        if pos_idx in self.occupied_cells:
            return self._state(), -1.0, False, False, {'ucov': 0.0, 'acov': 0.0}

        x, y = self._cell_to_xy(pos_idx)
        h = self.height_levels[h_idx]
        self.base_stations.append(model.init_base_station(h, (x, y)))
        self.uav_positions.append((x, y))
        self.uav_heights.append(h)
        self.occupied_cells.add(pos_idx)

        ucov, acov = self._cov()

        # 使用 3 项目标函数作为奖励
        r = model.objective_function(
            self.size, self.grid, self.coverage_grid,
            self.users, self.base_stations
        )

        done = len(self.uav_positions) >= self.num_uav
        if done:
            r += model.objective_function(
                self.size, self.grid, self.coverage_grid,
                self.users, self.base_stations
            )

        return self._state(), r, done, False, {'ucov': ucov, 'acov': acov}


# Actor-Critic 网络
class ActorCritic(nn.Module):
    def __init__(self, s, a, hidden=128):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(s, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU()
        )
        self.actor = nn.Linear(hidden, a)
        self.critic = nn.Linear(hidden, 1)

    def forward(self, x):
        f = self.shared(x)
        return self.actor(f), self.critic(f)


# PPO 智能体
class PPOAgent:
    def __init__(self, s, a, hidden=128, lr=3e-5, gamma=0.99, lam=0.95,
                 clip=0.2, epochs=10, batch_size=64):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.net = ActorCritic(s, a, hidden).to(self.device)
        self.opt = optim.Adam(self.net.parameters(), lr=lr)
        self.gamma, self.lam, self.clip = gamma, lam, clip
        self.epochs, self.batch_size = epochs, batch_size

        self.buffer_s, self.buffer_a, self.buffer_lp = [], [], []
        self.buffer_r, self.buffer_v, self.buffer_d = [], [], []

    # 选择动作
    def act(self, s, valid_mask=None):
        with torch.no_grad():
            t = torch.FloatTensor(s).unsqueeze(0).to(self.device)
            logits, v = self.net(t)
            if valid_mask is not None:
                logits[0, ~torch.BoolTensor(valid_mask).to(self.device)] = -1e9
            dist = torch.distributions.Categorical(logits=logits)
            a = dist.sample()
            lp = dist.log_prob(a).sum()
        return int(a.item()), lp.item(), v.item()

    # 存储经验
    def store(self, s, a, lp, r, v, d):
        self.buffer_s.append(s)
        self.buffer_a.append(a)
        self.buffer_lp.append(lp)
        self.buffer_r.append(r)
        self.buffer_v.append(v)
        self.buffer_d.append(d)

    # 清空缓存
    def clear(self):
        self.buffer_s, self.buffer_a, self.buffer_lp = [], [], []
        self.buffer_r, self.buffer_v, self.buffer_d = [], [], []

    # 计算 GAE
    def _gae(self, last_v):
        T = len(self.buffer_r)
        adv = np.zeros(T, dtype=np.float32)
        ret = np.zeros(T, dtype=np.float32)
        g = 0.0
        for t in reversed(range(T)):
            next_v = last_v if t == T - 1 else self.buffer_v[t + 1]
            non_term = 1.0 - self.buffer_d[t]
            delta = (self.buffer_r[t] + self.gamma * next_v * non_term
                     - self.buffer_v[t])
            g = delta + self.gamma * self.lam * non_term * g
            adv[t] = g
            ret[t] = g + self.buffer_v[t]
        return adv, ret

    # 更新网络
    def update(self, last_v):
        if len(self.buffer_r) == 0:
            return
        adv, ret = self._gae(last_v)
        S = torch.FloatTensor(np.array(self.buffer_s)).to(self.device)
        A = torch.LongTensor(np.array(self.buffer_a)).to(self.device)
        LP = torch.FloatTensor(np.array(self.buffer_lp)).to(self.device)
        ADV = torch.FloatTensor(adv).to(self.device)
        RET = torch.FloatTensor(ret).to(self.device)

        ADV = (ADV - ADV.mean()) / (ADV.std() + 1e-8)
        T = len(S)

        for _ in range(self.epochs):
            idx = np.random.permutation(T)
            for i in range(0, T, self.batch_size):
                b = idx[i:i + self.batch_size]
                logits, values = self.net(S[b])
                dist = torch.distributions.Categorical(logits=logits)
                new_lp = dist.log_prob(A[b])
                entropy = dist.entropy().mean()

                ratio = torch.exp(new_lp - LP[b])
                surr1 = ratio * ADV[b]
                surr2 = torch.clamp(ratio, 1.0 - self.clip,
                                    1.0 + self.clip) * ADV[b]
                actor_loss = -torch.min(surr1, surr2).mean()
                critic_loss = nn.MSELoss()(values.squeeze(-1), RET[b])

                loss = actor_loss + 0.5 * critic_loss - 0.02 * entropy

                self.opt.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.net.parameters(), 0.5)
                self.opt.step()

    # 保存模型
    def save(self, path):
        torch.save(self.net.state_dict(), path)

    # 加载模型
    def load(self, path):
        self.net.load_state_dict(torch.load(path, map_location=self.device))


# 离线训练主流程
def train_offline(num_episodes=5000, early_stop_patience=500, verbose=True):
    p = model.canshu()
    SIZE = p['size']
    NUM_UAV = p['num_base_stations']
    NUM_USERS = p['num_users']

    print(f"Params: size={SIZE}, num_uav={NUM_UAV}, num_users={NUM_USERS}")

    env = DeploymentEnv(size=SIZE, num_uav=NUM_UAV, num_users=NUM_USERS)
    agent = PPOAgent(env.observation_space.shape[0], env.action_space.n)

    current_dir = os.path.dirname(os.path.abspath(__file__))
    save_path = os.path.join(current_dir, "ppo_pretrained1.pth")

    print(f"\n[Offline] PPO training {num_episodes} episodes...")
    best_ucov, best_acov, best_uall = 0.0, 0.0, 0.0
    best_fgbest = -float('inf')
    no_improve = 0
    t0 = time.time()

    for ep in range(num_episodes):
        env.reset(seed=None)
        s = env._state()
        agent.clear()
        done = False
        info = {'ucov': 0.0, 'acov': 0.0}

        while not done:
            valid_mask = env.get_valid_action_mask()
            if not valid_mask.any():
                break
            a, lp, v = agent.act(s, valid_mask)
            ns, r, done, _, info = env.step(a)
            agent.store(s, a, lp, r, v, float(done))
            s = ns
            if done:
                break

        with torch.no_grad():
            _, last_v = agent.net(
                torch.FloatTensor(s).unsqueeze(0).to(agent.device))
            last_v = last_v.item()
        agent.update(last_v)

        # 使用 3 项目标函数评估当前 episode
        grid_eval = np.zeros((SIZE, SIZE), dtype=float)
        cov_eval = np.zeros((SIZE, SIZE), dtype=int)
        if env.base_stations:
            model.update_coverage(grid_eval, cov_eval,
                                  env.base_stations, SIZE)
            current_fgbest = model.objective_function(
                SIZE, grid_eval, cov_eval,
                env.users, env.base_stations
            )
            uall_eval = model.calculate_uniformity(SIZE, grid_eval)
        else:
            current_fgbest = 0.0
            uall_eval = 0.0

        if current_fgbest > best_fgbest:
            best_fgbest = current_fgbest
            best_ucov = info['ucov']
            best_acov = info['acov']
            best_uall = uall_eval
            no_improve = 0
            agent.save(save_path)
            if verbose:
                print(f"  >> [Best] Ep {ep+1:5d} saved: "
                      f"ucov={info['ucov']:.2%}, acov={info['acov']:.2%}, "
                      f"uall={uall_eval:.4f}, fgbest={current_fgbest:.4f}")
        else:
            no_improve += 1

        if verbose and (ep + 1) % 100 == 0:
            print(f"  Ep {ep+1:5d}/{num_episodes} | "
                  f"ucov={info['ucov']:.2%} | acov={info['acov']:.2%} | "
                  f"uall={uall_eval:.4f} | best_fgbest={best_fgbest:.4f} | "
                  f"no_improve={no_improve}")

        if no_improve >= early_stop_patience:
            print(f"\n[Offline] Early stop at ep {ep+1} "
                  f"(no improve for {early_stop_patience} episodes)")
            break

    print(f"\n[Offline] Done. best_ucov={best_ucov:.2%}, "
          f"best_acov={best_acov:.2%}, best_uall={best_uall:.4f}, "
          f"best_fgbest={best_fgbest:.4f}")
    print(f"[Offline] Time = {time.time() - t0:.1f}s")
    print(f"[Offline] Model saved to {save_path}")


if __name__ == "__main__":
    train_offline(num_episodes=5000, early_stop_patience=500, verbose=True)