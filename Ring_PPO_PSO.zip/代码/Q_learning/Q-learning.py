import os
import time
import random
from collections import defaultdict
import numpy as np
import pandas as pd
import model

# 从 txt 文件读取用户数据
def load_users_from_txt(path):
    users = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) == 2:
                x, y = float(parts[0]), float(parts[1])
                users.append({'pos': (x, y)})
            elif len(parts) == 4:
                x, y, r, s = map(float, parts)
                users.append({'pos': (x, y), 'radius': r, 'speed': s})
            else:
                raise ValueError(f"Cannot parse line: {line}")
    return users


# 计算三维空间体积覆盖率
def calculate_volume_coverage(env, vertical_layers=10, horizontal_resolution=2):
    size = env.size
    if len(env.base_stations) == 0:
        return 0.0
    grid_size = int(size / horizontal_resolution)
    cell_area = horizontal_resolution * horizontal_resolution
    height_max = 300.0
    layer_h = height_max / vertical_layers

    total_volume = 0.0
    covered_volume = 0.0
    for i in range(grid_size):
        for j in range(grid_size):
            x = (i + 0.5) * horizontal_resolution
            y = (j + 0.5) * horizontal_resolution
            total_volume += cell_area * height_max
            for layer in range(vertical_layers):
                covered = False
                for bs in env.base_stations:
                    d_xy = np.hypot(x - bs['position'][0], y - bs['position'][1])
                    if d_xy <= bs['radius']:
                        covered = True
                        break
                if covered:
                    covered_volume += cell_area * layer_h
    return (covered_volume / total_volume) * 100 if total_volume > 0 else 0.0


# 计算部署与通信能耗
def calculate_energy(env):
    n = len(env.base_stations)
    deploy_energy = n * 5.0
    comm_energy = 0.0
    for bs in env.base_stations:
        area = np.pi * bs['radius'] ** 2
        comm_energy += 0.01 * area * 0.02
    return deploy_energy + comm_energy


# 动态通信环境
class DynamicCommunicationEnv:
    def __init__(self, size=None, num_uav=None, num_users=None,
                 grid_res=6,
                 height_levels=(400, 450, 500),
                 user_move=False,
                 users_txt="users.txt"):
        params = model.canshu()
        self.size = size if size is not None else params['size']
        self.num_uav = num_uav if num_uav is not None else params['num_base_stations']
        self.num_users = num_users if num_users is not None else params['num_users']

        self.grid_res = grid_res
        self.height_levels = list(height_levels)
        self.n_pos = grid_res * grid_res
        self.n_height = len(self.height_levels)
        self.n_actions = self.n_pos * self.n_height

        self.user_move = user_move
        self.rng = np.random.RandomState()

        self.users_txt = users_txt
        self.users_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), users_txt)

        # dBm 底噪
        self.grid = np.full((self.size, self.size), model.NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)

        self.terrain_size = self.size
        self.max_bs_deploy = self.num_uav
        self.bs_list = []
        self.deployed_bs_indices = []
        self.uav_list = []
        self.users = []
        self.final_user_snrs = []
        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_cells = set()
        self.prev_ucov = 0.0
        self.prev_acov = 0.0
        self.prev_fitness = 0.0

    # 网格索引转二维坐标
    def _cell_to_xy(self, cell_idx):
        i = cell_idx // self.grid_res
        j = cell_idx % self.grid_res
        x = (i + 0.5) / self.grid_res * self.size
        y = (j + 0.5) / self.grid_res * self.size
        return x, y

    # 构建状态向量
    def get_state(self):
        s = np.zeros(self.num_uav * 3, dtype=np.float32)
        for k, (pos, h) in enumerate(zip(self.uav_positions, self.uav_heights)):
            s[k * 3]     = pos[0] / self.size
            s[k * 3 + 1] = pos[1] / self.size
            s[k * 3 + 2] = h / 500.0

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))

        extra = np.array([
            len(self.uav_positions) / self.num_uav,
            ucov,
            acov,
            1.0 if len(self.uav_positions) == 0 else 0.0,
        ], dtype=np.float32)
        return np.concatenate([s, extra]).astype(np.float32)

    # 重置环境
    def reset(self, seed=None):
        if seed is not None:
            self.rng = np.random.RandomState(seed)

        if not os.path.exists(self.users_path):
            raise FileNotFoundError(f"User file does not exist: {self.users_path}")
        self.users = load_users_from_txt(self.users_path)

        if self.user_move:
            for _ in range(5):
                model.move_users_random_walk(self.users, self.size)

        self.uav_positions = []
        self.base_stations = []
        self.uav_heights = []
        self.grid = np.full((self.size, self.size), model.NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)
        self.occupied_cells = set()

        self.prev_ucov = 0.0
        self.prev_acov = 0.0
        self.prev_fitness = 0.0

        self.bs_list = self.base_stations
        self.deployed_bs_indices = list(self.occupied_cells)
        self.uav_list = self.base_stations

        return self.get_state()

    # 有效动作掩码
    def get_valid_action_mask(self):
        mask = np.ones(self.n_actions, dtype=bool)
        for c in self.occupied_cells:
            for h_idx in range(self.n_height):
                mask[c * self.n_height + h_idx] = False
        return mask

    # 执行动作
    def take_action(self, action):
        action = int(action)
        pos_idx = action // self.n_height
        h_idx = action % self.n_height

        if pos_idx in self.occupied_cells:
            return self.get_state(), -5.0, False

        x, y = self._cell_to_xy(pos_idx)
        h = self.height_levels[h_idx]

        bs = model.init_base_station(h, (x, y))
        self.base_stations.append(bs)
        self.uav_positions.append((x, y))
        self.uav_heights.append(h)
        self.occupied_cells.add(pos_idx)

        self.bs_list = self.base_stations
        self.uav_list = self.base_stations
        self.deployed_bs_indices = list(self.occupied_cells)

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))

        cur_fitness = model.objective_function(
            self.size, self.grid, self.coverage_grid,
            self.users, self.base_stations)

        reward = (cur_fitness - self.prev_fitness) + 0.3 * cur_fitness
        self.prev_fitness = cur_fitness

        self.prev_ucov = ucov
        self.prev_acov = acov

        done = (len(self.uav_positions) >= self.num_uav)
        if done:
            reward += cur_fitness * 0.5

        return self.get_state(), reward, done

    # 获取用户覆盖率
    def get_coverage_rate(self):
        return model.user_coverage(self.users, self.base_stations) * 100

    # 获取全局覆盖率
    def get_acov(self):
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        return float(np.mean(self.coverage_grid)) * 100

    # 计算体积覆盖率
    def calculate_volume_coverage(self, vertical_layers=10, horizontal_resolution=2):
        return calculate_volume_coverage(self, vertical_layers, horizontal_resolution)


# Q-Learning 智能体
class QLearningAgent:
    def __init__(self, state_bins, n_actions, learning_rate=0.1,
                 discount_factor=0.95, epsilon=1.0,
                 epsilon_min=0.05):
        self.q_table = defaultdict(lambda: defaultdict(float))
        self.alpha = learning_rate
        self.gamma = discount_factor
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.state_bins = state_bins
        self.n_actions = n_actions

    # 状态离散化
    def discretize_state(self, state):
        discrete_state = []
        for i, bins in enumerate(self.state_bins):
            discrete_val = np.digitize(state[i], bins) - 1
            discrete_val = np.clip(discrete_val, 0, len(bins) - 1)
            discrete_state.append(discrete_val)
        return tuple(discrete_state)

    # 选择动作
    def choose_action(self, state, valid_mask=None):
        discrete_state = self.discretize_state(state)
        if random.random() < self.epsilon:
            if valid_mask is not None and valid_mask.any():
                valid_idx = np.where(valid_mask)[0]
                return int(np.random.choice(valid_idx))
            return random.randrange(self.n_actions)
        else:
            q_values = self.q_table[discrete_state]
            best_action, best_q = 0, -float('inf')
            for a in range(self.n_actions):
                if valid_mask is not None and not valid_mask[a]:
                    continue
                q = q_values.get(a, 0.0)
                if q > best_q:
                    best_q = q
                    best_action = a
            return best_action

    # Q 值更新
    def learn(self, state, action, reward, next_state, done):
        discrete_state = self.discretize_state(state)
        discrete_next_state = self.discretize_state(next_state)
        current_q = self.q_table[discrete_state][action]
        if done:
            target_q = reward
        else:
            max_next_q = max(self.q_table[discrete_next_state].values(), default=0.0)
            target_q = reward + self.gamma * max_next_q
        self.q_table[discrete_state][action] = current_q + self.alpha * (target_q - current_q)

    # epsilon 衰减
    def update_epsilon_by_episode(self, ep, total_ep):
        frac = min(1.0, ep / (total_ep * 0.6))
        self.epsilon = 1.0 - frac * (1.0 - self.epsilon_min)


def create_state_bins(env, num_bins=3):
    state = env.get_state()
    state_dim = state.shape[0]
    return [np.linspace(-1, 1, num_bins) for _ in range(state_dim)]

# 训练 Q-Learning 智能体
def train_q_learning_agent(env, episodes=300, verbose=True):
    state_bins = create_state_bins(env, num_bins=3)
    n_actions = env.n_actions

    agent = QLearningAgent(
        state_bins=state_bins,
        n_actions=n_actions,
        learning_rate=0.1,
        discount_factor=0.95,
        epsilon=1.0,
        epsilon_min=0.05)

    rewards_history = []
    coverage_history = []
    acov_history = []

    nfe_history = []
    fgbest_history = []
    current_nfe = 0

    for episode in range(episodes):
        agent.update_epsilon_by_episode(episode, episodes)

        env.reset(seed=None)
        state = env.get_state()
        episode_reward = 0
        done = False
        step = 0

        while not done and step < env.num_uav:
            step += 1
            valid_mask = env.get_valid_action_mask()
            action = agent.choose_action(state, valid_mask)
            next_state, reward, done = env.take_action(action)
            agent.learn(state, action, reward, next_state, done)
            state = next_state
            episode_reward += reward

            current_nfe += 1

        rewards_history.append(episode_reward)
        coverage = env.get_coverage_rate()
        coverage_history.append(coverage)
        acov = env.get_acov()
        acov_history.append(acov)

        f1 = acov / 100.0
        f2 = coverage / 100.0
        if env.base_stations:
            f3 = model.calculate_uniformity(env.size, env.grid)
        else:
            f3 = 0.0
        current_fgbest = model.objective_function(
            env.size, env.grid, env.coverage_grid,
            env.users, env.base_stations
        )
        fgbest_history.append(current_fgbest)
        nfe_history.append(current_nfe)

        if verbose and (episode + 1) % 50 == 0:
            print(f"    Episode {episode + 1}/{episodes} | "
                  f"reward={episode_reward:.4f} | "
                  f"f1={f1:.2%} | f2={f2:.2%} | f3={f3:.4f} | "
                  f"fitness={current_fgbest:.4f} | NFE={current_nfe} | "
                  f"eps={agent.epsilon:.3f} | Q={len(agent.q_table)}")

    return agent, rewards_history, coverage_history, acov_history, nfe_history, fgbest_history

def build_result_row(iteration, env, agent, rewards, coverage, acov_list,
                     nfe_history, fgbest_history, total_time):
    final_ucov = model.user_coverage(env.users, env.base_stations)
    model.update_coverage(env.grid, env.coverage_grid,
                          env.base_stations, env.size)
    final_acov = float(np.mean(env.coverage_grid))
    final_f3 = model.calculate_uniformity(env.size, env.grid)
    final_obj = model.objective_function(
        env.size, env.grid, env.coverage_grid,
        env.users, env.base_stations)

    base_station_positions = ";".join([
        f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
        for bs in env.base_stations])

    result = {
        'Run': iteration,
        'f1 (Global Coverage)': final_acov,
        'f2 (User Coverage)':   final_ucov,
        'f3 (Uniformity)':  final_f3,
        'Fitness':              final_obj,
        'Time (s)':             total_time,
        'Base Station Positions': base_station_positions,
    }
    result[''] = None
    for t, v in enumerate(fgbest_history):
        result[f"fitness {t + 1}"] = v
    result[' '] = None
    for t, v in enumerate(nfe_history):
        result[f"nfe {t + 1}"] = v
    return result


if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))

    NUM_RUNS = 20
    EPISODES_PER_RUN = 1000
    USERS_TXT = "users.txt"

    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n Run {i + 1} / {NUM_RUNS} ")
        env = DynamicCommunicationEnv(users_txt=USERS_TXT)
        start_time = time.time()

        agent, rewards, coverage, acov_list, nfe_history, fgbest_history = \
            train_q_learning_agent(env, episodes=EPISODES_PER_RUN, verbose=True)

        total_time = time.time() - start_time

        final_ucov = model.user_coverage(env.users, env.base_stations)
        model.update_coverage(env.grid, env.coverage_grid,
                              env.base_stations, env.size)
        final_acov = float(np.mean(env.coverage_grid))
        final_f3 = model.calculate_uniformity(env.size, env.grid)
        final_obj = model.objective_function(
            env.size, env.grid, env.coverage_grid,
            env.users, env.base_stations)

        print(f"  >> Run {i + 1} final: "
              f"f1={final_acov:.2%}, f2={final_ucov:.2%}, "
              f"f3={final_f3:.4f}, Fitness={final_obj:.4f}, "
              f"time={total_time:.1f}s")

        if final_obj > best_obj:
            best_obj = final_obj
            best_f1 = final_acov
            best_f2 = final_ucov
            best_f3 = final_f3
            best_run_id = i + 1

        all_results.append(build_result_row(
            i + 1, env, agent, rewards, coverage, acov_list,
            nfe_history, fgbest_history, total_time))

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    excel_path = os.path.join(current_dir, "Q_learning_results.xlsx")
    pd.DataFrame(all_results).to_excel(excel_path, index=False)

    print(f"\nExcel saved to {excel_path}")