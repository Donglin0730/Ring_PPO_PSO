import os
import time
import random
import numpy as np
import pandas as pd
import model

# 从 txt 文件读取用户数据
def read_parameters(file_path):
    params = {}
    content = None
    for enc in ['utf-8', 'utf-8-sig', 'gbk']:
        try:
            with open(file_path, 'r', encoding=enc) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue

    if content is None:
        raise RuntimeError(f"Cannot decode file: {file_path}")

    for line in content.splitlines():
        parts = line.split(':')
        if len(parts) == 2:
            name = parts[0].strip()
            try:
                values = list(map(float, parts[1].strip().split(',')))
                params[name] = values
            except ValueError:
                continue
    return params


def load_iteration_params():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.join(script_dir, "iterations.txt")
    if os.path.exists(candidate):
        print(f"Loading iteration params from {candidate}")
        return read_parameters(candidate)
    print(f"WARNING: {candidate} not found, using built-in defaults")
    T = 500
    return {
        'w':  [0.9 - 0.5 * t / T for t in range(T)],
        'c1': [2.5 - 2.0 * t / T for t in range(T)],
        'c2': [0.5 + 2.0 * t / T for t in range(T)],
        'c3': [0.5 + 1.5 * t / T for t in range(T)],
    }


params = load_iteration_params()


def run_ahdpso_once(p, max_runtime_seconds=300, verbose=True, record_interval=10):
    size      = p['size']
    num_bs    = p['num_base_stations']
    N         = p['num_particles']

    original_max_iter = p['max_iterations']

    # 用户随机生成
    users = model.init_users(
        num_users=p['num_users'],
        size=size,
        radius_range=(15, 25),
        speed_range=(1, 3)
    )

    # 初始化粒子群
    x = [[list(np.random.uniform(0, size, 2)) +
          [np.random.uniform(400, 500)]
          for _ in range(num_bs)] for _ in range(N)]
    v = [[[0, 0, 0] for _ in range(num_bs)] for _ in range(N)]

    fitness = [-float('inf')] * N
    Xgbest = x[fitness.index(max(fitness))].copy()
    fgbest = max(fitness)
    Xpbest = [xi.copy() for xi in x]
    fpbest = fitness.copy()

    start_time = time.time()

    # 记录固定时间点的历史最优适应度
    fitness_history = {}
    next_target_time = record_interval

    t = 0
    len_w  = len(params['w'])
    len_c1 = len(params['c1'])
    len_c2 = len(params['c2'])
    len_c3 = len(params['c3'])

    if verbose:
        print(f"    [AHDPSO] Start (Time Limit: {max_runtime_seconds}s, Interval: {record_interval}s)")

    while time.time() - start_time < max_runtime_seconds:
        elapsed_time = time.time() - start_time

        # 按时间间隔记录
        while elapsed_time >= next_target_time and next_target_time <= max_runtime_seconds:
            fitness_history[f"time_{next_target_time}"] = fgbest
            if verbose:
                print(f"    [{next_target_time:4d}s] Iter {t:5d} | fgbest = {fgbest:.6f}")
            next_target_time += record_interval

        # 将时间进度映射到参数索引
        time_progress = elapsed_time / max_runtime_seconds
        param_idx = int(time_progress * original_max_iter)

        w  = params['w'][param_idx % len_w]
        c1 = params['c1'][param_idx % len_c1]
        c2 = params['c2'][param_idx % len_c2]
        c3 = params['c3'][param_idx % len_c3]

        x_arr = np.array(x)
        encoded = np.rint(x_arr[:, :, :2]).astype(int) % 4

        hamming_distances = []
        for i in range(N):
            diffs = np.sum(encoded != encoded[i], axis=(1, 2))
            avg_distance = np.mean(np.delete(diffs, i))
            hamming_distances.append(avg_distance)

        # 找到平均距离最大的粒子作为 xworst
        max_avg_distance = max(hamming_distances)
        candidates = [i for i, dist in enumerate(hamming_distances) if dist == max_avg_distance]

        if len(candidates) > 1:
            xworst_idx = min(candidates, key=lambda idx: fitness[idx])
        else:
            xworst_idx = candidates[0]
        xworst = x[xworst_idx]

        # 速度与位置更新
        for i in range(N):
            r1 = np.random.rand()
            r2 = np.random.rand()
            r3 = np.random.rand()
            for j in range(num_bs):
                for k in range(3):
                    v[i][j][k] = (w * v[i][j][k]
                                  + c1 * r1 * (Xpbest[i][j][k] - x[i][j][k])
                                  + c2 * r2 * (Xgbest[j][k] - x[i][j][k])
                                  + c3 * r3 * (xworst[j][k] - x[i][j][k]))
                    x[i][j][k] += v[i][j][k]
                # 边界约束
                x[i][j][0] = max(0, min(x[i][j][0], size - 1))
                x[i][j][1] = max(0, min(x[i][j][1], size - 1))
                x[i][j][2] = max(400, min(x[i][j][2], 500))

        # 评估适应度
        for h in range(N):
            base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                             for bs in x[h]]
            grid = np.full((size, size), model.NOISE_DBM, dtype=float)
            coverage_grid = np.zeros((size, size), dtype=int)
            model.update_coverage(grid, coverage_grid, base_stations, size)

            fitness[h] = model.objective_function(
                size, grid, coverage_grid, users, base_stations
            )

            if fitness[h] > fpbest[h]:
                fpbest[h] = fitness[h]
                Xpbest[h] = [bs.copy() for bs in x[h]]

        if max(fpbest) > fgbest:
            fgbest = max(fpbest)
            Xgbest = Xpbest[fpbest.index(fgbest)].copy()

        t += 1

    # 计算总耗时
    total_time = time.time() - start_time

    # 重新计算最终最优解的各个指标
    grid = np.full((size, size), model.NOISE_DBM, dtype=float)
    coverage_grid = np.zeros((size, size), dtype=int)
    base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                     for bs in Xgbest]
    model.update_coverage(grid, coverage_grid, base_stations, size)

    final_ucov = model.user_coverage(users, base_stations)
    final_acov = float(np.mean(coverage_grid))
    final_f3   = model.calculate_uniformity(size, grid)
    final_obj  = model.objective_function(
        size, grid, coverage_grid, users, base_stations
    )

    return {
        'Xgbest': Xgbest,
        'users': users,
        'base_stations': base_stations,
        'ucov': final_ucov,
        'acov': final_acov,
        'f3': final_f3,
        'objective': final_obj,
        'fitness_history': fitness_history,
        'total_time': total_time,
        'iterations': t
    }


def build_result_row(iteration, result, fixed_time_columns):
    # 将结果封装为字典
    result_row = {
        'Run': iteration,
        'f1 (Global Coverage)': result['acov'],
        'f2 (User Coverage)':   result['ucov'],
        'f3 (Uniformity)':  result['f3'],
        'Fitness':              result['objective'],
        'Time (s)':             result['total_time'],
        'Iterations':           result['iterations'],
        'Base Station Positions': ";".join(
            [f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
             for bs in result['base_stations']]
        ),
    }
    # 填充固定时间点的历史适应度
    for col in fixed_time_columns:
        result_row[col] = result['fitness_history'].get(col, result['objective'])
    return result_row


if __name__ == "__main__":
    p = model.canshu()
    NUM_RUNS = 20
    # 总运行时间
    MAX_RUNTIME_SECONDS = 500
    # 记录间隔
    RECORD_INTERVAL = 10

    fixed_time_columns = [f"time_{j}" for j in range(RECORD_INTERVAL, MAX_RUNTIME_SECONDS + 1, RECORD_INTERVAL)]

    current_dir = os.path.dirname(os.path.abspath(__file__))
    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n--- Run {i + 1} / {NUM_RUNS} (Time limit: {MAX_RUNTIME_SECONDS}s) ---")

        result = run_ahdpso_once(p, max_runtime_seconds=MAX_RUNTIME_SECONDS, 
                                 verbose=True, record_interval=RECORD_INTERVAL)

        print(f"  >> Run {i + 1} Final: f1={result['acov']:.2%}, f2={result['ucov']:.2%}, "
              f"f3={result['f3']:.4f}, Fitness={result['objective']:.4f}, "
              f"Runtime={result['total_time']:.1f}s")

        if result['objective'] > best_obj:
            best_obj  = result['objective']
            best_f1   = result['acov']
            best_f2   = result['ucov']
            best_f3   = result['f3']
            best_run_id  = i + 1

        all_results.append(build_result_row(i + 1, result, fixed_time_columns))

        excel_path = os.path.join(current_dir, "AHDPSO_results.xlsx")
        try:
            pd.DataFrame(all_results).to_excel(excel_path, index=False)
        except Exception as e:
            print(f"Failed to save Excel: {e}")
            print("Please check if the file is currently open in Excel or WPS and close it before rerunning.")

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    print(f"\nAll runs completed! Excel saved.")