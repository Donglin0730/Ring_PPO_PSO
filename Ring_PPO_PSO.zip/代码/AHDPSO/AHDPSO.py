import os
import time
import random
import numpy as np
import pandas as pd
import model

#读取用户txt文件
def load_users_from_txt(path):
    users = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) == 2:
                x, y = float(parts[0]), float(parts[1])
                users.append({'pos': (x, y)})
            elif len(parts) == 4:
                x, y, r, s = map(float, parts)
                users.append({'pos': (x, y), 'radius': r, 'speed': s})
            else:
                raise ValueError(f"Cannot parse line: {line}")
    return users


def read_parameters(file_path):
    params = {}
    content = None
    for enc in ['utf-8', 'utf-8-sig', 'gbk']:
        try:
            with open(file_path, 'r', encoding=enc) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue

    if content is None:
        raise RuntimeError(f"Cannot decode file: {file_path}")

    for line in content.splitlines():
        parts = line.split(':')
        if len(parts) == 2:
            name = parts[0].strip()
            try:
                values = list(map(float, parts[1].strip().split(',')))
                params[name] = values
            except ValueError:
                continue
    return params


def load_iteration_params():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.join(script_dir, "iterations.txt")
    if os.path.exists(candidate):
        print(f"Loading iteration params from {candidate}")
        return read_parameters(candidate)
    print(f"WARNING: {candidate} not found, using built-in defaults")
    T = 500
    return {
        'w':  [0.9 - 0.5 * t / T for t in range(T)],
        'c1': [2.5 - 2.0 * t / T for t in range(T)],
        'c2': [0.5 + 2.0 * t / T for t in range(T)],
        'c3': [0.5 + 1.5 * t / T for t in range(T)],
    }


params = load_iteration_params()


def run_ahdpso_once(p, users_txt=None):

    #提取参数
    size      = p['size']
    num_bs    = p['num_base_stations']
    N         = p['num_particles']
    iterators = p['max_iterations']

    if users_txt is None:
        users_txt = "users.txt"
    users_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              users_txt)
    if not os.path.exists(users_path):
        raise FileNotFoundError(f"User file does not exist: {users_path}")
    users = load_users_from_txt(users_path)

    # 初始化粒子群
    x = [[list(np.random.uniform(0, size, 2)) +
          [np.random.uniform(400, 500)]
          for _ in range(num_bs)] for _ in range(N)]
    v = [[[0, 0, 0] for _ in range(num_bs)] for _ in range(N)]

    fitness = [-float('inf')] * N
    Xgbest = x[fitness.index(max(fitness))].copy()
    fgbest = max(fitness)
    Xpbest = [xi.copy() for xi in x]
    fpbest = fitness.copy()
    start_time = time.time()
    nfe_history = []
    fgbest_history = []
    current_nfe = 0

    len_w  = len(params['w'])
    len_c1 = len(params['c1'])
    len_c2 = len(params['c2'])
    len_c3 = len(params['c3'])

    for t in range(iterators):
        # 动态调整学习因子
        w  = params['w'][t % len_w]
        c1 = params['c1'][t % len_c1]
        c2 = params['c2'][t % len_c2]
        c3 = params['c3'][t % len_c3]

        # 编码粒子位置并计算平均汉明距离
        encoded_positions = [
            [['A', 'C', 'G', 'T'][int(round(val)) % 4] for bs in xi for val in bs]
            for xi in x
        ]
        hamming_distances = []
        for i in range(len(encoded_positions)):
            distances = []
            for j in range(len(encoded_positions)):
                if i != j:
                    distance = sum(
                        ch1 != ch2
                        for ch1, ch2 in zip(encoded_positions[i],
                                            encoded_positions[j]))
                    distances.append(distance)
            avg_distance = np.mean(distances) if distances else 0
            hamming_distances.append(avg_distance)

        # 找到平均距离最大的粒子作为 xworst
        max_avg_distance = max(hamming_distances)
        candidates = [i for i, dist in enumerate(hamming_distances)
                      if dist == max_avg_distance]
        if len(candidates) > 1:
            xworst_idx = min(candidates, key=lambda idx: fitness[idx])
        else:
            xworst_idx = candidates[0]
        xworst = x[xworst_idx]

        #速度与位置更新
        for i in range(N):
            r1 = np.random.rand()
            r2 = np.random.rand()
            r3 = np.random.rand()
            for j in range(num_bs):
                for k in range(3):
                    v[i][j][k] = (w * v[i][j][k]
                                  + c1 * r1 * (Xpbest[i][j][k] - x[i][j][k])
                                  + c2 * r2 * (Xgbest[j][k] - x[i][j][k])
                                  + c3 * r3 * (xworst[j][k] - x[i][j][k]))
                    x[i][j][k] += v[i][j][k]
                # 边界约束
                x[i][j][0] = max(0, min(x[i][j][0], size - 1))
                x[i][j][1] = max(0, min(x[i][j][1], size - 1))
                x[i][j][2] = max(400, min(x[i][j][2], 500))

        #评估适应度
        for h in range(N):
            base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                             for bs in x[h]]
            # 覆盖网格计算
            grid = np.full((size, size), model.NOISE_DBM, dtype=float)
            coverage_grid = np.zeros((size, size), dtype=int)
            model.update_coverage(grid, coverage_grid, base_stations, size)

            #目标函数
            fitness[h] = model.objective_function(
                size, grid, coverage_grid, users, base_stations
            )

            if fitness[h] > fpbest[h]:
                fpbest[h] = fitness[h]
                Xpbest[h] = [bs.copy() for bs in x[h]]

        if max(fpbest) > fgbest:
            fgbest = max(fpbest)
            Xgbest = Xpbest[fpbest.index(fgbest)].copy()

        current_nfe += N
        fgbest_history.append(fgbest)
        nfe_history.append(current_nfe)

        if (t + 1) % 50 == 0:
            bs_eval = [model.init_base_station(bs[2], (bs[0], bs[1]))
                       for bs in Xgbest]
            grid_eval = np.full((size, size), model.NOISE_DBM, dtype=float)
            cov_eval = np.zeros((size, size), dtype=int)
            model.update_coverage(grid_eval, cov_eval, bs_eval, size)
            ucov_step = model.user_coverage(users, bs_eval)
            acov_step = float(np.mean(cov_eval))
            f3_step = model.calculate_uniformity(size, grid_eval)
            print(f"    Iter {t+1:5d} | f1={acov_step:.2%} | "
                  f"f2={ucov_step:.2%} | f3={f3_step:.4f} | "
                  f"Fitness={fgbest:.4f} | NFE={current_nfe}")

    #计算总耗时
    total_time = time.time() - start_time

    # 重新计算最终最优解的各个指标
    grid = np.full((size, size), model.NOISE_DBM, dtype=float)
    coverage_grid = np.zeros((size, size), dtype=int)
    base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                     for bs in Xgbest]
    model.update_coverage(grid, coverage_grid, base_stations, size)

    final_ucov = model.user_coverage(users, base_stations)
    final_acov = float(np.mean(coverage_grid))
    final_f3   = model.calculate_uniformity(size, grid)
    final_obj  = model.objective_function(
        size, grid, coverage_grid, users, base_stations
    )

    return {
        'Xgbest': Xgbest,
        'users': users,
        'base_stations': base_stations,
        'ucov': final_ucov,
        'acov': final_acov,
        'f3': final_f3,
        'objective': final_obj,
        'nfe_history': nfe_history,
        'fgbest_history': fgbest_history,
        'total_time': total_time,
    }


def build_result_row(iteration, result):
    # 将结果封装为字典
    result_row = {
        'Run': iteration,
        'f1 (Global Coverage)': result['acov'],
        'f2 (User Coverage)':   result['ucov'],
        'f3 (Uniformity)':  result['f3'],
        'Fitness':              result['objective'],
        'Time (s)':             result['total_time'],
        'Base Station Positions': ";".join(
            [f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
             for bs in result['base_stations']]
        ),
    }
    result_row[''] = None
    for t, v in enumerate(result['fgbest_history']):
        result_row[f"fitness {t + 1}"] = v
    result_row[' '] = None
    for t, v in enumerate(result['nfe_history']):
        result_row[f"nfe {t + 1}"] = v
    return result_row


if __name__ == "__main__":
    p = model.canshu()
    NUM_RUNS = 20

    current_dir = os.path.dirname(os.path.abspath(__file__))
    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n Run {i + 1} / {NUM_RUNS} ")
        result = run_ahdpso_once(p)

        print(f"  >> Run {i + 1} final: "
              f"f1={result['acov']:.2%}, f2={result['ucov']:.2%}, "
              f"f3={result['f3']:.4f}, Fitness={result['objective']:.4f}, "
              f"time={result['total_time']:.1f}s")

        if result['objective'] > best_obj:
            best_obj  = result['objective']
            best_f1   = result['acov']
            best_f2   = result['ucov']
            best_f3   = result['f3']
            best_run_id  = i + 1

        all_results.append(build_result_row(i + 1, result))

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    excel_path = os.path.join(current_dir, "AHDPSO_results.xlsx")
    pd.DataFrame(all_results).to_excel(excel_path, index=False)

    print(f"\nExcel saved to {excel_path}")