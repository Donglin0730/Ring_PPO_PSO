import os
import random
import time
from collections import deque
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import model

# 计算三维空间体积覆盖率
def calculate_volume_coverage(env, vertical_layers=10, horizontal_resolution=2):
    size = env.size
    if len(env.base_stations) == 0:
        return 0.0
    grid_size = int(size / horizontal_resolution)
    cell_area = horizontal_resolution * horizontal_resolution
    height_max = 300.0
    layer_h = height_max / vertical_layers
    total_volume = 0.0
    covered_volume = 0.0
    for i in range(grid_size):
        for j in range(grid_size):
            x = (i + 0.5) * horizontal_resolution
            y = (j + 0.5) * horizontal_resolution
            total_volume += cell_area * height_max
            for layer in range(vertical_layers):
                covered = False
                for bs in env.base_stations:
                    d_xy = np.hypot(x - bs['position'][0], y - bs['position'][1])
                    if d_xy <= bs['radius']:
                        covered = True
                        break
                if covered:
                    covered_volume += cell_area * layer_h
    return (covered_volume / total_volume) * 100 if total_volume > 0 else 0.0


# 计算部署与通信能耗
def calculate_energy(env):
    n = len(env.base_stations)
    deploy_energy = n * 5.0
    comm_energy = 0.0
    for bs in env.base_stations:
        area = np.pi * bs['radius'] ** 2
        comm_energy += 0.01 * area * 0.02
    return deploy_energy + comm_energy


# 动态通信环境
class DynamicCommunicationEnv:
    def __init__(self, size=None, num_uav=None, num_users=None,
                 grid_res=6,
                 height_levels=(400, 450, 500),
                 user_move=False):
        params = model.canshu()
        self.size = size if size is not None else params['size']
        self.num_uav = num_uav if num_uav is not None else params['num_base_stations']
        self.num_users = num_users if num_users is not None else params['num_users']

        self.grid_res = grid_res
        self.height_levels = list(height_levels)
        self.n_pos = grid_res * grid_res
        self.n_height = len(self.height_levels)
        self.n_actions = self.n_pos * self.n_height

        self.user_move = user_move
        self.rng = np.random.RandomState()

        self.grid = np.full((self.size, self.size), 1e-10)
        self.coverage_grid = np.zeros((self.size, self.size))

        self.users = []
        self.base_stations = []
        self.uav_positions = []
        self.uav_heights = []
        self.occupied_cells = set()
        self.prev_ucov = 0.0
        self.prev_acov = 0.0
        self.prev_f3 = 0.0

    # 将网格索引映射为二维坐标
    def _cell_to_xy(self, cell_idx):
        i = cell_idx // self.grid_res
        j = cell_idx % self.grid_res
        x = (i + 0.5) / self.grid_res * self.size
        y = (j + 0.5) / self.grid_res * self.size
        return x, y

    # 构建状态向量
    def get_state(self):
        s = np.zeros(self.num_uav * 3, dtype=np.float32)
        for k, (pos, h) in enumerate(zip(self.uav_positions, self.uav_heights)):
            s[k * 3]     = pos[0] / self.size
            s[k * 3 + 1] = pos[1] / self.size
            s[k * 3 + 2] = h / 500.0

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))

        if len(self.base_stations) > 0:
            f3 = model.calculate_uniformity(self.size, self.grid)
        else:
            f3 = 0.0

        extra = np.array([
            len(self.uav_positions) / self.num_uav,
            ucov, acov, f3,
            1.0 if len(self.uav_positions) == 0 else 0.0,
        ], dtype=np.float32)
        return np.concatenate([s, extra]).astype(np.float32)

    # 重置环境
    def reset(self, seed=None):
        params = model.canshu()
        self.users = model.init_users(
            self.num_users, self.size,
            radius_range=params['user_radius_range'],
            speed_range=params['user_speed_range'],
            seed=None)
        if self.user_move:
            for _ in range(5):
                model.move_users_random_walk(self.users, self.size)

        self.uav_positions = []
        self.base_stations = []
        self.uav_heights = []
        self.grid = np.full((self.size, self.size), 1e-10)
        self.coverage_grid = np.zeros((self.size, self.size))
        self.occupied_cells = set()

        self.prev_ucov = 0.0
        self.prev_acov = 0.0
        self.prev_f3 = 0.0
        return self.get_state()

    # 有效动作掩码
    def get_valid_action_mask(self):
        mask = np.ones(self.n_actions, dtype=bool)
        for c in self.occupied_cells:
            for h_idx in range(self.n_height):
                mask[c * self.n_height + h_idx] = False
        return mask

    # 执行动作
    def take_action(self, action):
        action = int(action)
        pos_idx = action // self.n_height
        h_idx = action % self.n_height

        if pos_idx in self.occupied_cells:
            return self.get_state(), -5.0, False

        x, y = self._cell_to_xy(pos_idx)
        h = self.height_levels[h_idx]

        bs = model.init_base_station(h, (x, y))
        self.base_stations.append(bs)
        self.uav_positions.append((x, y))
        self.uav_heights.append(h)
        self.occupied_cells.add(pos_idx)

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))
        f3 = model.calculate_uniformity(self.size, self.grid)

        reward = model.objective_function(
            self.size, self.grid, self.coverage_grid,
            self.users, self.base_stations
        )

        self.prev_ucov = ucov
        self.prev_acov = acov
        self.prev_f3 = f3

        done = (len(self.uav_positions) >= self.num_uav)
        if done:
            reward += model.objective_function(
                self.size, self.grid, self.coverage_grid,
                self.users, self.base_stations
            )

        return self.get_state(), reward, done

    # 获取用户覆盖率
    def get_coverage_rate(self):
        return model.user_coverage(self.users, self.base_stations) * 100

    # 获取均匀性
    def get_uall(self):
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        if len(self.base_stations) == 0:
            return 0.0
        return model.calculate_uniformity(self.size, self.grid)


# DQN 智能体
class DQNAgent:
    def __init__(self, state_size, action_size, hidden=256,
                 lr=1e-3, gamma=0.95,
                 epsilon=1.0, epsilon_min=0.05,
                 buffer_size=100000,
                 batch_size=128,
                 target_update_tau=0.005, device=None):
        self.state_size = state_size
        self.action_size = action_size
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.batch_size = batch_size
        self.tau = target_update_tau
        self.memory = deque(maxlen=buffer_size)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        self.model = self._build_model(hidden).to(self.device)
        self.target_model = self._build_model(hidden).to(self.device)
        self.target_model.load_state_dict(self.model.state_dict())
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.loss_fn = nn.MSELoss()

    # 构建神经网络
    def _build_model(self, hidden):
        if isinstance(hidden, int):
            hidden_sizes = [hidden, hidden]
        else:
            hidden_sizes = list(hidden)
        layers = []
        in_dim = self.state_size
        for h in hidden_sizes:
            layers += [nn.Linear(in_dim, h), nn.ReLU()]
            in_dim = h
        layers.append(nn.Linear(in_dim, self.action_size))
        return nn.Sequential(*layers)

    # epsilon 衰减
    def update_epsilon_by_episode(self, ep, total_ep):
        frac = min(1.0, ep / (total_ep * 0.6))
        self.epsilon = 1.0 - frac * (1.0 - self.epsilon_min)

    # 选择动作
    def act(self, state, valid_mask=None, greedy=False):
        if (not greedy) and (np.random.rand() <= self.epsilon):
            if valid_mask is not None and valid_mask.any():
                valid_idx = np.where(valid_mask)[0]
                return int(np.random.choice(valid_idx))
            return np.random.randint(self.action_size)

        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            q = self.model(state_t).cpu().numpy()[0]
        if valid_mask is not None:
            q = np.where(valid_mask, q, -1e9)
        return int(np.argmax(q))

    # 存储经验
    def remember(self, s, a, r, s2, done):
        self.memory.append((s, a, r, s2, done))

    # 经验回放
    def replay(self):
        if len(self.memory) < self.batch_size:
            return None
        minibatch = random.sample(self.memory, self.batch_size)
        states = torch.FloatTensor(np.array([m[0] for m in minibatch])).to(self.device)
        actions = torch.LongTensor([m[1] for m in minibatch]).unsqueeze(1).to(self.device)
        rewards = torch.FloatTensor([m[2] for m in minibatch]).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(np.array([m[3] for m in minibatch])).to(self.device)
        dones = torch.FloatTensor([float(m[4]) for m in minibatch]).unsqueeze(1).to(self.device)

        q_pred = self.model(states).gather(1, actions)
        with torch.no_grad():
            q_next = self.target_model(next_states).max(1, keepdim=True)[0]
            q_target = rewards + self.gamma * q_next * (1.0 - dones)

        loss = self.loss_fn(q_pred, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=10.0)
        self.optimizer.step()
        return float(loss.item())

    # 软更新目标网络
    def soft_update_target(self):
        for tp, p in zip(self.target_model.parameters(), self.model.parameters()):
            tp.data.copy_(self.tau * p.data + (1.0 - self.tau) * tp.data)


# DERL 算法
class DERL:
    def __init__(self, state_size, action_size,
                 population_size=8, mutation_rate=0.1):
        self.state_size = state_size
        self.action_size = action_size
        self.population_size = population_size
        self.mutation_rate = mutation_rate
        self.population = self._initialize_population()
        self.fitness_scores = np.zeros(population_size)

    # 初始化种群
    def _initialize_population(self):
        population = []
        for _ in range(self.population_size):
            hidden_layers = random.randint(1, 3)
            hidden_sizes = [random.choice([128, 256, 512]) for _ in range(hidden_layers)]
            individual = {
                'hidden_sizes': hidden_sizes,
                'learning_rate': random.choice([5e-4, 1e-3, 2e-3]),
                'gamma': random.choice([0.9, 0.95, 0.99]),
            }
            population.append(individual)
        return population

    # 变异
    def mutate(self, individual):
        mutated = individual.copy()
        mutated['hidden_sizes'] = mutated['hidden_sizes'][:]
        if random.random() < self.mutation_rate:
            if len(mutated['hidden_sizes']) > 1 and random.random() < 0.3:
                mutated['hidden_sizes'] = mutated['hidden_sizes'][:-1]
            elif random.random() < 0.3:
                mutated['hidden_sizes'].append(random.choice([128, 256, 512]))
            else:
                idx = random.randint(0, len(mutated['hidden_sizes']) - 1)
                mutated['hidden_sizes'][idx] = random.choice([128, 256, 512])
        if random.random() < self.mutation_rate:
            mutated['learning_rate'] = random.choice([5e-4, 1e-3, 2e-3])
        if random.random() < self.mutation_rate:
            mutated['gamma'] = random.choice([0.9, 0.95, 0.99])
        return mutated

    # 交叉
    def crossover(self, p1, p2):
        child = {}
        child['hidden_sizes'] = p1['hidden_sizes'][:] if random.random() < 0.5 else p2['hidden_sizes'][:]
        child['learning_rate'] = p1['learning_rate'] if random.random() < 0.5 else p2['learning_rate']
        child['gamma'] = p1['gamma'] if random.random() < 0.5 else p2['gamma']
        return child

    # 锦标赛选择
    def select_parents(self, tournament_size=3):
        selected = []
        for _ in range(2):
            idxs = random.sample(range(self.population_size), tournament_size)
            fitnesses = [self.fitness_scores[i] for i in idxs]
            selected.append(self.population[idxs[np.argmax(fitnesses)]])
        return selected

    # 进化
    def evolve(self, elite_count=2):
        new_population = []
        elite_indices = np.argsort(self.fitness_scores)[-elite_count:]
        for idx in elite_indices:
            new_population.append(self.population[idx])
        while len(new_population) < self.population_size:
            if random.random() < 0.8:
                p = self.select_parents()
                new_population.append(self.crossover(p[0], p[1]))
            else:
                new_population.append(self.mutate(random.choice(self.population)))
        self.population = new_population[:self.population_size]

    # 创建 DQN
    def create_agent(self, individual):
        agent = DQNAgent(self.state_size, self.action_size,
                         hidden=individual['hidden_sizes'],
                         lr=individual['learning_rate'],
                         gamma=individual['gamma'])
        return agent


# 训练 DERL
def train_derl(num_episodes=300, size=None, num_uav=None, num_users=None,
               grid_res=6, eval_every=50, verbose=True,
               height_levels=(400, 450, 500),
               population_size=8,
               episodes_per_individual=None,
               verbose_individual=False):
    env = DynamicCommunicationEnv(size=size, num_uav=num_uav, num_users=num_users,
                                  grid_res=grid_res,
                                  user_move=False,
                                  height_levels=height_levels)

    state_size = env.get_state().shape[0]
    action_size = env.n_actions
    print(f"State dim: {state_size}, Action num: {action_size} "
          f"(pos {env.n_pos} x height {env.n_height})")

    derl = DERL(state_size, action_size, population_size=population_size)

    if episodes_per_individual is None:
        episodes_per_individual = num_episodes // (population_size * 5)
    episodes_per_individual = max(1, episodes_per_individual)
    generation_episodes = episodes_per_individual * population_size
    num_generations = max(1, num_episodes // generation_episodes)

    rewards = []
    ucovs = []
    acovs = []
    f3s = []
    nfe_history = []
    fgbest_history = []
    current_nfe = 0

    global_step = 0
    for generation in range(num_generations):
        if verbose:
            print(f"\n=== Generation {generation + 1}/{num_generations} ===")

        generation_fitness = []
        for i, individual in enumerate(derl.population):
            if global_step >= num_episodes:
                break

            if verbose_individual:
                print(f"  Individual {i + 1}/{len(derl.population)} "
                      f"hidden={individual['hidden_sizes']} "
                      f"lr={individual['learning_rate']} gamma={individual['gamma']}")

            agent = derl.create_agent(individual)
            episode_rewards = []

            for local_ep in range(episodes_per_individual):
                if global_step >= num_episodes:
                    break

                agent.update_epsilon_by_episode(local_ep, episodes_per_individual)

                state = env.reset(seed=None)
                total_reward = 0.0
                done = False

                # 智能体与环境交互
                while not done:
                    valid_mask = env.get_valid_action_mask()
                    action = agent.act(state, valid_mask)
                    next_state, reward, done = env.take_action(action)
                    agent.remember(state, action, reward, next_state, done)
                    agent.replay()
                    agent.soft_update_target()
                    state = next_state
                    total_reward += reward
                    current_nfe += 1

                ucov = env.get_coverage_rate() / 100
                model.update_coverage(env.grid, env.coverage_grid,
                                      env.base_stations, env.size)
                acov = float(np.mean(env.coverage_grid))
                f3 = model.calculate_uniformity(env.size, env.grid)

                rewards.append(total_reward)
                ucovs.append(ucov)
                acovs.append(acov)
                f3s.append(f3)
                episode_rewards.append(total_reward)
                global_step += 1

                current_fgbest = model.objective_function(
                    env.size, env.grid, env.coverage_grid,
                    env.users, env.base_stations
                )
                fgbest_history.append(current_fgbest)
                nfe_history.append(current_nfe)

                if verbose and (global_step % 50 == 0):
                    print(f"Ep {global_step:5d} | reward={total_reward:8.4f} | "
                          f"f1={acov:.2%} | f2={ucov:.2%} | f3={f3:.4f} | "
                          f"fitness={current_fgbest:.4f} | NFE={current_nfe}")

                # 定期贪心评估
                if (global_step % eval_every == 0):
                    eval_state = env.reset(seed=None)
                    eval_done = False
                    while not eval_done:
                        mask = env.get_valid_action_mask()
                        a = agent.act(eval_state, mask, greedy=True)
                        eval_state, _, eval_done = env.take_action(a)
                    eval_ucov = model.user_coverage(env.users, env.base_stations)
                    model.update_coverage(env.grid, env.coverage_grid,
                                          env.base_stations, env.size)
                    eval_acov = float(np.mean(env.coverage_grid))
                    eval_f3 = model.calculate_uniformity(env.size, env.grid)
                    print(f"  >> Eval @ ep {global_step}: "
                          f"f1={eval_acov:.2%}, f2={eval_ucov:.2%}, f3={eval_f3:.4f}")

            fitness = np.mean(episode_rewards) if episode_rewards else 0.0
            derl.fitness_scores[i] = fitness
            generation_fitness.append(fitness)

            if global_step >= num_episodes:
                break

        derl.evolve(elite_count=2)
        if verbose:
            print(f"  Generation {generation + 1} | "
                  f"best_fit={np.max(generation_fitness):.4f} | "
                  f"avg_fit={np.mean(generation_fitness):.4f}")

    rewards = rewards[:num_episodes]
    ucovs = ucovs[:num_episodes]
    acovs = acovs[:num_episodes]
    f3s = f3s[:num_episodes]
    nfe_history = nfe_history[:num_episodes]
    fgbest_history = fgbest_history[:num_episodes]

    return env, derl, rewards, ucovs, acovs, f3s, nfe_history, fgbest_history


def build_result_row(iteration, env, rewards, nfe_history, fgbest_history, total_time):
    final_f2 = model.user_coverage(env.users, env.base_stations)
    model.update_coverage(env.grid, env.coverage_grid,
                          env.base_stations, env.size)
    final_f1 = float(np.mean(env.coverage_grid))
    final_f3 = (model.calculate_uniformity(env.size, env.grid)
                if len(env.base_stations) > 0 else 0.0)
    final_obj = model.objective_function(
        env.size, env.grid, env.coverage_grid,
        env.users, env.base_stations
    )

    base_station_positions = ";".join(
        [f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
         for bs in env.base_stations])

    result = {
        'Run': iteration,
        'f1 (Global Coverage)': final_f1,
        'f2 (User Coverage)': final_f2,
        'f3 (Uniformity)': final_f3,
        'Fitness': final_obj,
        'Time (s)': total_time,
        'Base Station Positions': base_station_positions,
    }
    result[''] = None
    for t, v in enumerate(fgbest_history):
        result[f"fitness {t + 1}"] = v
    result[' '] = None
    for t, v in enumerate(nfe_history):
        result[f"nfe {t + 1}"] = v
    return result

if __name__ == "__main__":
    NUM_RUNS = 20
    EPISODES_PER_RUN = 300

    current_dir = os.path.dirname(os.path.abspath(__file__))

    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n DERL Run {i + 1} / {NUM_RUNS} ")
        start_time = time.time()

        (env, derl, rewards, ucovs, acovs, f3s,
         nfe_history, fgbest_history) = train_derl(
            num_episodes=EPISODES_PER_RUN,
            grid_res=6,
            eval_every=50,
            verbose=True,
            height_levels=(400, 450, 500),
            population_size=8,
            episodes_per_individual=None,
            verbose_individual=False)

        total_time = time.time() - start_time

        final_f2 = model.user_coverage(env.users, env.base_stations)
        model.update_coverage(env.grid, env.coverage_grid,
                              env.base_stations, env.size)
        final_f1 = float(np.mean(env.coverage_grid))
        final_f3 = (model.calculate_uniformity(env.size, env.grid)
                    if len(env.base_stations) > 0 else 0.0)
        final_obj = model.objective_function(
            env.size, env.grid, env.coverage_grid,
            env.users, env.base_stations
        )

        print(f"  >> Run {i + 1} final: f1={final_f1:.2%}, "
              f"f2={final_f2:.2%}, f3={final_f3:.4f}, "
              f"Fitness={final_obj:.4f}, time={total_time:.1f}s")

        if final_obj > best_obj:
            best_obj = final_obj
            best_f1 = final_f1
            best_f2 = final_f2
            best_f3 = final_f3
            best_run_id = i + 1

        all_results.append(build_result_row(
            iteration=i + 1, env=env, rewards=rewards,
            nfe_history=nfe_history, fgbest_history=fgbest_history,
            total_time=total_time))

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness       = {best_obj:.4f}")
    print(f"  Best f1 (Global)   = {best_f1:.2%}")
    print(f"  Best f2 (User)     = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity) = {best_f3:.4f}")

    excel_path = os.path.join(current_dir, "DERL1_results.xlsx")
    pd.DataFrame(all_results).to_excel(excel_path, index=False)

    print(f"\nExcel saved to {excel_path}")