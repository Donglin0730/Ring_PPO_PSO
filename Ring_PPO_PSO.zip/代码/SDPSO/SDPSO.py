import os
import time
import numpy as np
import pandas as pd
from model import (canshu, init_base_station, init_users,
                   update_coverage, user_coverage,
                   calculate_uniformity, objective_function,
                   NOISE_DBM)

# 从 txt 文件读取用户数据
def load_users_from_txt(path):
    users = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) == 2:
                x, y = float(parts[0]), float(parts[1])
                users.append({'pos': (x, y)})
            elif len(parts) == 4:
                x, y, r, s = map(float, parts)
                users.append({'pos': (x, y), 'radius': r, 'speed': s})
            else:
                raise ValueError(f"Cannot parse line: {line}")
    return users


def metropolis_criterion(new_reward, old_reward, temperature):
    if new_reward > old_reward:
        return True
    else:
        p = np.exp((new_reward - old_reward) / max(temperature, 1e-8))
        return p > np.random.rand()


def dimensional_learning(particle, global_best, m_threshold,
                         current_iter, max_iter):
    if current_iter > m_threshold:
        for j in range(len(particle)):
            dim = np.random.randint(0, 3)
            particle[j][dim] = global_best[j][dim]
    return particle


# SDPSO 单次运行
def run_sdpso_once(p, users_txt=None):
    size = p['size']
    num_bs = p['num_base_stations']
    N = p['num_particles']
    iterators = p['max_iterations']

    if users_txt is None:
        users_txt = "users.txt"
    users_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              users_txt)
    if not os.path.exists(users_path):
        raise FileNotFoundError(f"User file does not exist: {users_path}")
    users = load_users_from_txt(users_path)

    initial_temp = 1000
    m_ratio = 0.3
    m_threshold = int(m_ratio * iterators)

    # 初始化粒子群
    x = [[list(np.random.uniform(0, size, 2)) +
          [np.random.uniform(400, 500)]
          for _ in range(num_bs)] for _ in range(N)]
    v = [[[0, 0, 0] for _ in range(num_bs)] for _ in range(N)]

    fitness = [-float('inf')] * N
    w_max, w_min = 0.9, 0.4
    Xgbest = x[fitness.index(max(fitness))].copy()
    fgbest = max(fitness)
    Xpbest = [xi.copy() for xi in x]
    fpbest = fitness.copy()

    start_time = time.time()
    nfe_history = []
    fgbest_history = []
    current_nfe = 0
    prev_fgbest = None

    for t in range(iterators):
        # 动态调整惯性权重和学习因子
        w = w_max - (w_max - w_min) * (t / iterators)
        temperature = initial_temp * (1 - t / iterators)
        c1 = 2.0 - (2.0 - 0.4) * (t / iterators)
        c2 = 0.4 + (2.0 - 0.4) * (t / iterators)

        # 速度与位置更新
        for i in range(N):
            r1, r2 = np.random.rand(), np.random.rand()
            for j in range(num_bs):
                for k in range(3):
                    v[i][j][k] = (w * v[i][j][k]
                                  + c1 * r1 * (Xpbest[i][j][k] - x[i][j][k])
                                  + c2 * r2 * (Xgbest[j][k] - x[i][j][k]))
                    x[i][j][k] += v[i][j][k]

            # 维度学习
            x[i] = dimensional_learning(x[i], Xgbest,
                                        m_threshold, t, iterators)

            # 边界约束
            for j in range(num_bs):
                x[i][j][0] = max(0, min(x[i][j][0], size - 1))
                x[i][j][1] = max(0, min(x[i][j][1], size - 1))
                x[i][j][2] = max(400, min(x[i][j][2], 500))

        # 评估适应度
        for h in range(N):
            base_stations = [init_base_station(bs[2], (bs[0], bs[1]))
                             for bs in x[h]]
            grid = np.full((size, size), NOISE_DBM, dtype=float)
            coverage_grid = np.zeros((size, size), dtype=int)
            update_coverage(grid, coverage_grid, base_stations, size)

            fitness[h] = objective_function(
                size, grid, coverage_grid, users, base_stations
            )

            if fitness[h] > fpbest[h]:
                fpbest[h] = fitness[h]
                Xpbest[h] = [bs.copy() for bs in x[h]]

        current_best_idx = int(np.argmax(fpbest))
        if metropolis_criterion(fpbest[current_best_idx],
                                fgbest, temperature):
            fgbest = fpbest[current_best_idx]
            Xgbest = [bs.copy() for bs in Xpbest[current_best_idx]]

        current_nfe += N
        fgbest_history.append(fgbest)
        nfe_history.append(current_nfe)
        prev_fgbest = fgbest

        if (t + 1) % 50 == 0:
            bs_eval = [init_base_station(bs[2], (bs[0], bs[1]))
                       for bs in Xgbest]
            grid_eval = np.full((size, size), NOISE_DBM, dtype=float)
            cov_eval = np.zeros((size, size), dtype=int)
            update_coverage(grid_eval, cov_eval, bs_eval, size)

            ucov_step = user_coverage(users, bs_eval)
            acov_step = float(np.mean(cov_eval))
            uall_step = calculate_uniformity(size, grid_eval)

            print(f"    Iter {t+1:5d} | f1={acov_step:.2%} | "
                  f"f2={ucov_step:.2%} | f3={uall_step:.4f} | "
                  f"Fitness={fgbest:.4f} | NFE={current_nfe}")

    # 计算总耗时
    total_time = time.time() - start_time

    # 重新计算最终最优解的各个指标
    grid = np.full((size, size), NOISE_DBM, dtype=float)
    coverage_grid = np.zeros((size, size), dtype=int)
    base_stations = [init_base_station(bs[2], (bs[0], bs[1]))
                     for bs in Xgbest]
    update_coverage(grid, coverage_grid, base_stations, size)

    ucov = user_coverage(users, base_stations)
    acov = float(np.mean(coverage_grid))
    uall = calculate_uniformity(size, grid)
    final_obj = objective_function(size, grid, coverage_grid,
                                   users, base_stations)

    return {
        'Xgbest': Xgbest,
        'users': users,
        'base_stations': base_stations,
        'ucov': ucov,
        'acov': acov,
        'uall': uall,
        'objective': final_obj,
        'nfe_history': nfe_history,
        'fgbest_history': fgbest_history,
        'total_time': total_time,
    }


def build_result_row(iteration, result):
    # 将结果封装为字典
    result_row = {
        'Run': iteration,
        'f1 (Global Coverage)': result['acov'],
        'f2 (User Coverage)':   result['ucov'],
        'f3 (Uniformity)':  result['uall'],
        'Fitness':              result['objective'],
        'Time (s)':             result['total_time'],
        'Base Station Positions': ";".join(
            [f"({bs[0]:.2f}, {bs[1]:.2f}, {bs[2]:.2f})"
             for bs in result['Xgbest']]
        ),
    }
    result_row[''] = None
    for t, v in enumerate(result['fgbest_history']):
        result_row[f"fitness {t + 1}"] = v
    result_row[' '] = None
    for t, v in enumerate(result['nfe_history']):
        result_row[f"nfe {t + 1}"] = v
    return result_row


if __name__ == "__main__":
    p = canshu()
    NUM_RUNS = 20
    current_dir = os.path.dirname(os.path.abspath(__file__))
    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n Run {i + 1} / {NUM_RUNS} ")
        result = run_sdpso_once(p)

        print(f"  >> Run {i + 1} final: "
              f"f1={result['acov']:.2%}, "
              f"f2={result['ucov']:.2%}, "
              f"f3={result['uall']:.4f}, "
              f"Fitness={result['objective']:.4f}, "
              f"Time={result['total_time']:.1f}s")

        if result['objective'] > best_obj:
            best_obj = result['objective']
            best_f1 = result['acov']
            best_f2 = result['ucov']
            best_f3 = result['uall']
            best_run_id = i + 1

        all_results.append(build_result_row(i + 1, result))

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    excel_path = os.path.join(current_dir, "SDPSO_results.xlsx")
    pd.DataFrame(all_results).to_excel(excel_path, index=False)
    print(f"\nExcel saved to {excel_path}")