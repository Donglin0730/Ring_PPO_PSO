import os
import time
import random
import numpy as np
import pandas as pd
from model import (canshu, init_base_station, init_users,
                   update_coverage, user_coverage,
                   calculate_uniformity, objective_function,
                   load_buildings, NOISE_DBM)


# MPSO 单次运行
def run_mpso_once(p, max_runtime_seconds=300, verbose=True, record_interval=10):
    size = p['size']
    num_bs = p['num_base_stations']
    N = p['num_particles']
    dim = num_bs * 3

    buildings = load_buildings()

    # 用户随机生成
    users = init_users(
        num_users=p['num_users'],
        size=size,
        radius_range=(15, 25),
        speed_range=(1, 3),
        seed=None
    )

    # 初始化粒子群
    x = np.random.uniform(0, size, (N, dim))
    x[:, 2::3] = np.random.uniform(400, 500, (N, num_bs))
    v = np.zeros((N, dim))

    fitness = np.full(N, -float('inf'))

    w_max = 0.9
    w_min = 0.4
    c1 = 1.6
    c2 = 1.8

    Xgbest = x[fitness.argmax()].copy()
    fgbest = fitness.max()
    Xpbest = x.copy()
    fpbest = fitness.copy()

    start_time = time.time()

    fitness_history = {}
    next_target_time = record_interval
    t = 0

    if verbose:
        print(f"    [MPSO] Start (Time Limit: {max_runtime_seconds}s, Interval: {record_interval}s)")

    while time.time() - start_time < max_runtime_seconds:
        elapsed_time = time.time() - start_time

        # 按时间间隔记录
        while elapsed_time >= next_target_time and next_target_time <= max_runtime_seconds:
            fitness_history[f"time_{next_target_time}"] = fgbest
            if verbose:
                print(f"    [{next_target_time:4d}s] Iter {t:5d} | fgbest = {fgbest:.6f}")
            next_target_time += record_interval

        # 按时间进度调整惯性权重
        progress = elapsed_time / max_runtime_seconds
        w = w_max - (w_max - w_min) * progress

        # 速度与位置更新
        for i in range(N):
            r1 = np.random.rand()
            r2 = np.random.rand()

            v[i] = (w * v[i]
                    + c1 * r1 * (Xpbest[i] - x[i])
                    + c2 * r2 * (Xgbest - x[i]))
            x[i] += v[i]

            # 边界约束
            for j in range(dim):
                if j % 3 < 2:
                    x[i][j] = max(0, min(x[i][j], size - 1))
                else:
                    x[i][j] = max(400, min(x[i][j], 500))

        # 评估适应度
        for h in range(N):
            base_stations = [init_base_station(x[h, j * 3 + 2],
                                               (x[h, j * 3], x[h, j * 3 + 1]))
                             for j in range(num_bs)]
            # dBm 底噪
            grid = np.full((size, size), NOISE_DBM, dtype=float)
            coverage_grid = np.zeros((size, size), dtype=int)
            update_coverage(grid, coverage_grid, base_stations, size)

            # 目标函数
            fitness[h] = objective_function(
                size, grid, coverage_grid, users, base_stations
            )

            if fitness[h] > fpbest[h]:
                fpbest[h] = fitness[h]
                Xpbest[h] = x[h].copy()

        if fpbest.max() > fgbest:
            fgbest = fpbest.max()
            Xgbest = Xpbest[fpbest.argmax()].copy()

        t += 1

    # 计算总耗时
    total_time = time.time() - start_time

    # 重新计算最终最优解的各个指标
    grid = np.full((size, size), NOISE_DBM, dtype=float)
    coverage_grid = np.zeros((size, size), dtype=int)
    base_stations = [init_base_station(Xgbest[j * 3 + 2],
                                       (Xgbest[j * 3], Xgbest[j * 3 + 1]))
                     for j in range(num_bs)]
    update_coverage(grid, coverage_grid, base_stations, size)
    ucov = user_coverage(users, base_stations)
    acov = float(np.mean(coverage_grid))
    f3_final = calculate_uniformity(size, grid)
    final_obj = objective_function(size, grid, coverage_grid,
                                   users, base_stations)

    return {
        'Xgbest': Xgbest,
        'num_bs': num_bs,
        'users': users,
        'base_stations': base_stations,
        'ucov': ucov,
        'acov': acov,
        'f3': f3_final,
        'objective': final_obj,
        'fitness_history': fitness_history,
        'total_time': total_time,
        'iterations': t
    }


def build_result_row(iteration, result, fixed_time_columns):
    num_bs = result['num_bs']
    # 将结果封装为字典
    result_row = {
        'Run': iteration,
        'f1 (Global Coverage)': result['acov'],
        'f2 (User Coverage)':   result['ucov'],
        'f3 (Uniformity)':  result['f3'],
        'Fitness':              result['objective'],
        'Time (s)':             result['total_time'],
        'Iterations':           result['iterations'],
        'Base Station Positions': ";".join(
            [f"({result['Xgbest'][j * 3]:.2f}, "
             f"{result['Xgbest'][j * 3 + 1]:.2f}, "
             f"{result['Xgbest'][j * 3 + 2]:.2f})"
             for j in range(num_bs)]),
    }

    # 填充固定时间点的历史适应度
    for col in fixed_time_columns:
        result_row[col] = result['fitness_history'].get(col, result['objective'])

    return result_row


if __name__ == "__main__":
    p = canshu()
    NUM_RUNS = 20
    # 总运行时间
    MAX_RUNTIME_SECONDS = 500
    # 记录间隔
    RECORD_INTERVAL = 10

    fixed_time_columns = [f"time_{j}" for j in range(RECORD_INTERVAL, MAX_RUNTIME_SECONDS + 1, RECORD_INTERVAL)]

    current_dir = os.path.dirname(os.path.abspath(__file__))
    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n--- Run {i + 1} / {NUM_RUNS} (Time limit: {MAX_RUNTIME_SECONDS}s) ---")

        result = run_mpso_once(p, max_runtime_seconds=MAX_RUNTIME_SECONDS,
                               verbose=True, record_interval=RECORD_INTERVAL)

        print(f"  >> Run {i + 1} Final: "
              f"f1={result['acov']:.2%}, f2={result['ucov']:.2%}, "
              f"f3={result['f3']:.4f}, Fitness={result['objective']:.4f}, "
              f"Runtime={result['total_time']:.1f}s")

        if result['objective'] > best_obj:
            best_obj = result['objective']
            best_f1 = result['acov']
            best_f2 = result['ucov']
            best_f3 = result['f3']
            best_run_id = i + 1

        all_results.append(build_result_row(i + 1, result, fixed_time_columns))

        excel_path = os.path.join(current_dir, "MPSO_results.xlsx")
        try:
            pd.DataFrame(all_results).to_excel(excel_path, index=False)
        except Exception as e:
            print(f"Failed to save Excel: {e}")
            print("Please check if the file is currently open in Excel or WPS and close it before rerunning.")

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    print(f"\nAll runs completed! Excel saved.")