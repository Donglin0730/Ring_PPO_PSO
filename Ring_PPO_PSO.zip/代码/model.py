import os
import json
import random
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
from matplotlib.patches import Circle, Rectangle
from matplotlib.lines import Line2D


def canshu():
    return {
        'size': 50,
        'num_base_stations': 25,
        'num_particles': 30,
        'max_iterations': 500,
        'num_users': 70,
        'height_levels': (400, 450, 500),
        'user_radius_range': (15, 25),
        'user_speed_range': (1, 3),
        'num_time_steps': 10,
        'dt': 1.0
    }


NOISE_DBM = -200.0                 # 未覆盖区域的底噪
COVERAGE_THRESHOLD_DBM = -80.0     # 覆盖门限
ENV_ALPHA    = 9.61      # 视距概率模型参数 α
ENV_BETA     = 0.16      # 视距概率模型参数 β
ENV_ETA_LOS  = 1.0       # LoS 额外路径损耗 η_LoS
ENV_ETA_NLOS = 20.0      # NLoS 额外路径损耗 η_NLoS
CARRIER_FREQ_HZ = 2.4e9   #载波频率
LIGHT_SPEED     = 3e8     #光速


def init_base_station(height, position, angle_of_view=55):
    radius = (height / 100) * np.tan(np.radians(angle_of_view))
    return {'height': height, 'position': list(position), 'radius': radius}


def get_signal_strength(bs, x, y):
    val = get_signal_strength_batch(
        np.array([x], dtype=np.float64),
        np.array([y], dtype=np.float64),
        np.array([bs['position'][0]], dtype=np.float64),
        np.array([bs['position'][1]], dtype=np.float64),
        np.array([bs['height']], dtype=np.float64),
        np.array([bs['radius']], dtype=np.float64),
    )
    return float(val[0])


# 信号强度（mW）
def get_signal_strength_batch(x, y, bs_x, bs_y, bs_h, bs_r):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    bs_x = np.asarray(bs_x, dtype=np.float64)
    bs_y = np.asarray(bs_y, dtype=np.float64)
    bs_h = np.asarray(bs_h, dtype=np.float64)
    bs_r = np.asarray(bs_r, dtype=np.float64)

    dx = x - bs_x
    dy = y - bs_y
    distance_proj = np.sqrt(dx * dx + dy * dy)              # 水平距离

    within = distance_proj <= bs_r
    d_proj = np.where(distance_proj < 1e-3, 1e-3, distance_proj)
    distance = np.sqrt(d_proj ** 2 + (bs_h / 100.0) ** 2)   # 3D 距离


    common = 20.0 * np.log10(distance * 100.0) \
             + 20.0 * np.log10(4.0 * np.pi * CARRIER_FREQ_HZ / LIGHT_SPEED)

    #  LoS / NLoS 路径损耗 
    loss_los  = common + ENV_ETA_LOS
    loss_nlos = common + ENV_ETA_NLOS

    #  视距概率
    elevation_deg = np.degrees(np.arctan2(bs_h, d_proj + 1e-9))
    p_los = 1.0 / (1.0 + ENV_ALPHA * np.exp(-ENV_BETA * (elevation_deg - ENV_ALPHA)))

    # 加权总损耗
    loss = p_los * loss_los + (1.0 - p_los) * loss_nlos

    signal_dBm = 40.0 - loss
    valid = within & (signal_dBm >= COVERAGE_THRESHOLD_DBM)

    signal_mW = np.zeros_like(signal_dBm)
    signal_mW[valid] = 10.0 ** ((signal_dBm[valid] - 30.0) / 10.0)
    return signal_mW

# 信号强度（dBm）
def get_signal_strength_dbm_batch(x, y, bs_x, bs_y, bs_h, bs_r):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    bs_x = np.asarray(bs_x, dtype=np.float64)
    bs_y = np.asarray(bs_y, dtype=np.float64)
    bs_h = np.asarray(bs_h, dtype=np.float64)
    bs_r = np.asarray(bs_r, dtype=np.float64)

    dx = x - bs_x
    dy = y - bs_y
    distance_proj = np.sqrt(dx * dx + dy * dy)

    within = distance_proj <= bs_r
    d_proj = np.where(distance_proj < 1e-3, 1e-3, distance_proj)
    distance = np.sqrt(d_proj ** 2 + (bs_h / 100.0) ** 2)

    common = 20.0 * np.log10(distance * 100.0) \
             + 20.0 * np.log10(4.0 * np.pi * CARRIER_FREQ_HZ / LIGHT_SPEED)

    #  LoS / NLoS 路径损耗 
    loss_los  = common + ENV_ETA_LOS
    loss_nlos = common + ENV_ETA_NLOS

    #  视距概率
    elevation_deg = np.degrees(np.arctan2(bs_h, d_proj + 1e-9))
    p_los = 1.0 / (1.0 + ENV_ALPHA * np.exp(-ENV_BETA * (elevation_deg - ENV_ALPHA)))

    # 加权总损耗
    loss = p_los * loss_los + (1.0 - p_los) * loss_nlos

    signal_dBm = 40.0 - loss
    valid = within & (signal_dBm >= COVERAGE_THRESHOLD_DBM)

    out = np.full_like(signal_dBm, NOISE_DBM)
    out[valid] = signal_dBm[valid]
    return out


_BASE_TETROMINOES = [
    [(0, 0), (1, 0), (2, 0), (3, 0)],
    [(0, 0), (1, 0), (0, 1), (1, 1)],
    [(0, 0), (1, 0), (2, 0), (2, 1)],
    [(0, 0), (1, 0), (1, 1), (2, 1)],
    [(0, 1), (1, 1), (1, 0), (2, 0)],
    [(0, 0), (1, 0), (1, 1), (2, 1)],
    [(0, 0), (0, 1), (1, 1), (1, 0)],
]


def _normalize_cells(cells):
    min_x = min(c[0] for c in cells)
    min_y = min(c[1] for c in cells)
    return [(x - min_x, y - min_y) for x, y in cells]


def _random_shape(rng, min_blocks=1, max_blocks=4, max_size=5):
    num_blocks = rng.randint(min_blocks, max_blocks)
    cells = set()
    first = rng.choice(_BASE_TETROMINOES)
    for dx, dy in first:
        cells.add((dx, dy))

    for _ in range(num_blocks - 1):
        cand = rng.choice(_BASE_TETROMINOES)
        anchor = rng.choice(list(cells))
        off_x = anchor[0] - rng.randint(0, 3)
        off_y = anchor[1] - rng.randint(0, 3)
        new_cells = [(x + off_x, y + off_y) for x, y in cand]

        merged = cells.union(new_cells)
        max_x = max(c[0] for c in merged)
        min_x = min(c[0] for c in merged)
        max_y = max(c[1] for c in merged)
        min_y = min(c[1] for c in merged)
        if (max_x - min_x + 1) > max_size or (max_y - min_y + 1) > max_size:
            continue
        cells = merged

    return _normalize_cells(list(cells))


def init_buildings(size, num_buildings=100,
                   min_blocks=1, max_blocks=4,
                   max_shape_size=5,
                   min_height=10, max_height=40,
                   max_retries=100, seed=42):
    rng = random.Random(seed)
    np_rng = np.random.RandomState(seed)

    occupied_cells = set()
    buildings = []
    attempts = 0
    total_attempts = num_buildings * max_retries

    while len(buildings) < num_buildings and attempts < total_attempts:
        attempts += 1
        shape = _random_shape(rng,
                              min_blocks=min_blocks,
                              max_blocks=max_blocks,
                              max_size=max_shape_size)
        max_dx = max(dx for dx, dy in shape)
        max_dy = max(dy for dx, dy in shape)
        gx = rng.randint(0, size - max_dx - 1)
        gy = rng.randint(0, size - max_dy - 1)
        cells = [(gx + dx, gy + dy) for dx, dy in shape]

        if any(c in occupied_cells for c in cells):
            continue

        occupied_cells.update(cells)
        buildings.append({
            'cells': cells,
            'height': np_rng.uniform(min_height, max_height),
        })

    return buildings


def is_in_building(x, y, buildings):
    for b in buildings:
        for (cx, cy) in b['cells']:
            if cx <= x < cx + 1 and cy <= y < cy + 1:
                return True
    return False


def load_buildings():
    return init_buildings(
        size=50,
        num_buildings=100,
        min_blocks=1,
        max_blocks=4,
        max_shape_size=5,
        min_height=10,
        max_height=40,
        seed=42,
    )


def init_users(num_users, size, buildings=None, radius_range=(2, 5),
               speed_range=(0.1, 0.5), seed=None):
    rng = np.random.RandomState(seed)
    users = []
    for uid in range(num_users):
        x = rng.uniform(0, size)
        y = rng.uniform(0, size)
        r = rng.uniform(*radius_range)
        in_building = is_in_building(x, y, buildings) if buildings else False
        users.append({
            'id': uid,
            'pos': np.array([x, y], dtype=float),
            'home': np.array([x, y], dtype=float),
            'range': r,
            'speed': rng.uniform(*speed_range),
            'direction': rng.uniform(0, 2 * np.pi),
            'trajectory': [(x, y)],
            'in_building': in_building,
        })
    return users


def _unpack_base_stations(base_stations):
    n = len(base_stations)
    bx = np.empty(n, dtype=np.float64)
    by = np.empty(n, dtype=np.float64)
    bh = np.empty(n, dtype=np.float64)
    br = np.empty(n, dtype=np.float64)
    for k, bs in enumerate(base_stations):
        bx[k] = bs['position'][0]
        by[k] = bs['position'][1]
        bh[k] = bs['height']
        br[k] = bs['radius']
    return bx, by, bh, br


def user_coverage(users, base_stations):
    if len(users) == 0 or len(base_stations) == 0:
        return 0.0

    ux = np.array([u['pos'][0] for u in users], dtype=np.float64)
    uy = np.array([u['pos'][1] for u in users], dtype=np.float64)
    bx, by, bh, br = _unpack_base_stations(base_stations)

    UX = ux[:, None]; UY = uy[:, None]
    BX = bx[None, :]; BY = by[None, :]
    BH = bh[None, :]; BR = br[None, :]

    sig = get_signal_strength_batch(
        np.broadcast_to(UX, (len(ux), len(bx))).ravel(),
        np.broadcast_to(UY, (len(uy), len(by))).ravel(),
        np.broadcast_to(BX, (len(ux), len(bx))).ravel(),
        np.broadcast_to(BY, (len(uy), len(by))).ravel(),
        np.broadcast_to(BH, (len(ux), len(bx))).ravel(),
        np.broadcast_to(BR, (len(ux), len(bx))).ravel(),
    ).reshape(len(ux), len(bx))

    covered_mask = (sig > 0).any(axis=1)
    return float(covered_mask.mean())


def update_coverage(grid, coverage_grid, base_stations, size):
    grid.fill(NOISE_DBM)
    coverage_grid.fill(0)

    if len(base_stations) == 0:
        return

    n = size
    ii, jj = np.meshgrid(np.arange(n), np.arange(n), indexing='ij')
    cx = (ii + 0.5).astype(np.float64).ravel()
    cy = (jj + 0.5).astype(np.float64).ravel()

    bx, by, bh, br = _unpack_base_stations(base_stations)
    B = len(bx)

    CX = cx[:, None]; CY = cy[:, None]
    BX = bx[None, :]; BY = by[None, :]
    BH = bh[None, :]; BR = br[None, :]

    sig_dbm = get_signal_strength_dbm_batch(
        np.broadcast_to(CX, (cx.size, B)).ravel(),
        np.broadcast_to(CY, (cy.size, B)).ravel(),
        np.broadcast_to(BX, (cx.size, B)).ravel(),
        np.broadcast_to(BY, (cy.size, B)).ravel(),
        np.broadcast_to(BH, (cx.size, B)).ravel(),
        np.broadcast_to(BR, (cx.size, B)).ravel(),
    ).reshape(cx.size, B)

    best_dbm = sig_dbm.max(axis=1).reshape(n, n)

    grid[:, :] = best_dbm
    coverage_grid[:, :] = (best_dbm >= COVERAGE_THRESHOLD_DBM).astype(coverage_grid.dtype)


# 信号均匀度
def calculate_uniformity(size, grid, normalize=True, sigma_ref=10.0):
    P = grid.flatten()
    P = P[P >= COVERAGE_THRESHOLD_DBM]
    if len(P) < 2:
        return 0.0
    sigma = float(np.std(P))
    if normalize:
        return 1.0 / (1.0 + sigma)
    return sigma


# 目标函数
def objective_function(size, grid, coverage_grid, users, base_stations):
    f1 = float(np.mean(coverage_grid))                # f1：全局覆盖率
    f2 = user_coverage(users, base_stations)          # f2：用户覆盖率
    f3 = calculate_uniformity(size, grid)             # f3：信号均匀度

    fitness = 0.45 * f1 + 0.30 * f2 + 0.25 * f3
    return fitness


def calculate_coverage_and_uniformity(size, grid, coverage_grid, users, base_stations):
    f1 = float(np.mean(coverage_grid))
    f2 = user_coverage(users, base_stations)
    f3 = calculate_uniformity(size, grid)

    fitness = 0.45 * f1 + 0.30 * f2 + 0.25 * f3

    print(f"f1 (Global Coverage):       {f1:.2%}")
    print(f"f2 (User Coverage):         {f2:.2%}")
    print(f"f3 (Uniformity):            {f3:.4f}")
    print(f"Fitness (max):              {fitness:.4f}\n")
    return (f1, f2, f3, fitness)

# 可视化
def visualize_users(ax, users, show_range=True, show_traj=True):
    for u in users:
        x, y = u['pos']
        marker_color = 'red' if u.get('in_building', False) else 'green'
        ax.plot(x, y, '^', color=marker_color, markersize=6)
        if show_range:
            c = Circle((u['home'][0], u['home'][1]), u['range'], color=marker_color,
                       fill=False, linestyle='--', linewidth=0.8, alpha=0.5)
            ax.add_patch(c)
        if show_traj and len(u['trajectory']) > 1:
            traj = np.array(u['trajectory'])
            ax.plot(traj[:, 0], traj[:, 1], '-', color=marker_color,
                    linewidth=0.5, alpha=0.4)


def visualize_double_panel(iteration, base_stations, size,
                           users=None, buildings=None,
                           global_coverage_rate=0.0,
                           user_coverage_rate=0.0,
                           is_final=False,
                           algo_name="Algorithm",
                           save=True, show=True,
                           save_dir=None):
    if not is_final:
        return
    fig, ax = plt.subplots(1, 1, figsize=(12, 11), dpi=120)
    icon_path = "uav.png"
    try:
        icon = plt.imread(icon_path)
    except Exception:
        icon = None
    Z_COVER, Z_BUILD, Z_USER, Z_UAV_ICO = 1, 2, 20, 30
    UAV_ZOOM = 0.16
    USER_SIZE = 10
    ax.set_facecolor('#FAFAFA')
    ax.grid(True, linestyle=':', linewidth=0.5, color='#CCCCCC', zorder=0)

    for bs in base_stations:
        circle = Circle(bs['position'], bs['radius'],
                        facecolor='none', edgecolor='#808080',
                        linestyle='--', linewidth=1.6, alpha=0.9, zorder=Z_COVER)
        ax.add_patch(circle)

    if buildings is not None:
        for b in buildings:
            for (cx, cy) in b['cells']:
                rect = Rectangle((cx, cy), 1, 1,
                                 facecolor="#EED366", edgecolor='none',
                                 linewidth=0, alpha=0.75, zorder=Z_BUILD)
                ax.add_patch(rect)

    if users is not None:
        for u in users:
            x, y = u['pos']
            ax.plot(x, y, 'o', markersize=USER_SIZE,
                    markerfacecolor='#FF2D2D', markeredgecolor='none',
                    markeredgewidth=0, zorder=Z_USER)

    for bs in base_stations:
        if icon is not None:
            im = OffsetImage(icon, zoom=UAV_ZOOM)
            ab = AnnotationBbox(im, bs['position'], xycoords='data',
                                frameon=False, zorder=Z_UAV_ICO)
            ax.add_artist(ab)
        else:
            ax.plot(bs['position'][0], bs['position'][1], 'o',
                    markersize=USER_SIZE, markerfacecolor='#7E6BC4',
                    markeredgecolor='none', markeredgewidth=0, zorder=Z_UAV_ICO)

    ax.set_xlim(0, size)
    ax.set_ylim(0, size)
    ax.set_xticks(np.arange(0, size + 1, 5))
    ax.set_yticks(np.arange(0, size + 1, 5))
    ax.set_aspect('equal')
    ax.set_xlabel('')
    ax.set_ylabel('')

    title_text = (
        f"{algo_name}\n"
        f"Global Coverage Rate: {global_coverage_rate:.2%}\n"
        f"User Coverage Rate:   {user_coverage_rate:.2%}"
    )
    fig.suptitle(title_text, fontsize=16, fontweight='bold',
                 y=0.98, linespacing=1.6)

    plt.tight_layout(rect=[0, 0, 1, 0.94])

    if save:
        if save_dir is None:
            save_dir = os.path.dirname(os.path.abspath(__file__))
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        save_path = os.path.join(save_dir, f'{algo_name}_final_single.png')
        plt.savefig(save_path, dpi=200, bbox_inches='tight')
        print(f"Final deployment image saved to {save_path}")

    if show:
        plt.show()
    else:
        plt.close(fig)