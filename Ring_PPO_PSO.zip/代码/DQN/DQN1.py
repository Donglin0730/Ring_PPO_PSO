import os
import random
import time
from collections import deque
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import gymnasium as gym
from gymnasium import spaces
import model

# 计算三维空间体积覆盖率
def calculate_volume_coverage(env, vertical_layers=10, horizontal_resolution=2):
    size = env.size
    if len(env.base_stations) == 0:
        return 0.0
    grid_size = int(size / horizontal_resolution)
    cell_area = horizontal_resolution * horizontal_resolution
    height_max = 300.0
    layer_h = height_max / vertical_layers

    total_volume = 0.0
    covered_volume = 0.0
    for i in range(grid_size):
        for j in range(grid_size):
            x = (i + 0.5) * horizontal_resolution
            y = (j + 0.5) * horizontal_resolution
            total_volume += cell_area * height_max
            for layer in range(vertical_layers):
                covered = False
                for bs in env.base_stations:
                    d_xy = np.hypot(x - bs['position'][0], y - bs['position'][1])
                    if d_xy <= bs['radius']:
                        covered = True
                        break
                if covered:
                    covered_volume += cell_area * layer_h
    return (covered_volume / total_volume) * 100 if total_volume > 0 else 0.0

# 计算部署与通信能耗
def calculate_energy(env):
    n = len(env.base_stations)
    deploy_energy = n * 5.0
    comm_energy = 0.0
    for bs in env.base_stations:
        area = np.pi * bs['radius'] ** 2
        comm_energy += 0.01 * area * 0.02
    return deploy_energy + comm_energy

# 部署环境
class DeploymentEnv(gym.Env):
    def __init__(self, size=None, num_uav=None, num_users=None,
                 grid_res=6,
                 height_levels=(400, 450, 500),
                 user_move=False):
        super().__init__()

        params = model.canshu()

        self.size = size if size is not None else params['size']
        self.num_uav = num_uav if num_uav is not None else params['num_base_stations']
        self.num_users = num_users if num_users is not None else params['num_users']

        self.grid_res = grid_res
        self.height_levels = list(height_levels)
        self.n_pos = grid_res * grid_res
        self.n_height = len(self.height_levels)
        self.user_move = user_move
        self.rng = np.random.RandomState()

        self.action_space = spaces.Discrete(self.n_pos * self.n_height)
        self.observation_space = spaces.Box(
            low=-1.0, high=1.0,
            shape=(self.num_uav * 3 + 4,),
            dtype=np.float32
        )

        # dBm 底噪
        self.grid = np.full((self.size, self.size), model.NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)

        self.users = []
        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_cells = set()
        self.prev_ucov = 0.0
        self.prev_acov = 0.0
        self.prev_fitness = 0.0

    # 网格索引转二维坐标
    def _cell_to_xy(self, cell_idx):
        i = cell_idx // self.grid_res
        j = cell_idx % self.grid_res
        x = (i + 0.5) / self.grid_res * self.size
        y = (j + 0.5) / self.grid_res * self.size
        return x, y

    # 构建状态向量
    def _get_state(self):
        s = np.zeros(self.num_uav * 3, dtype=np.float32)
        for k, (pos, h) in enumerate(zip(self.uav_positions, self.uav_heights)):
            s[k * 3]     = pos[0] / self.size
            s[k * 3 + 1] = pos[1] / self.size
            s[k * 3 + 2] = h / 500.0

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))

        extra = np.array([
            len(self.uav_positions) / self.num_uav,
            ucov,
            acov,
            1.0 if len(self.uav_positions) == 0 else 0.0,
        ], dtype=np.float32)
        return np.concatenate([s, extra]).astype(np.float32)

    # 重置环境
    def reset(self, seed=None, options=None):
        params = model.canshu()

        self.users = model.init_users(
            self.num_users, self.size,
            radius_range=params['user_radius_range'],
            speed_range=params['user_speed_range'],
            seed=None
        )
        if self.user_move:
            for _ in range(5):
                model.move_users_random_walk(self.users, self.size)

        self.uav_positions = []
        self.base_stations = []
        self.uav_heights = []
        # dBm 底噪
        self.grid = np.full((self.size, self.size), model.NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)
        self.occupied_cells = set()

        self.prev_ucov = 0.0
        self.prev_acov = 0.0
        self.prev_fitness = 0.0

        return self._get_state(), {}

    # 有效动作掩码
    def get_valid_action_mask(self):
        mask = np.ones(self.action_space.n, dtype=bool)
        for c in self.occupied_cells:
            for h_idx in range(self.n_height):
                mask[c * self.n_height + h_idx] = False
        return mask

    # 执行动作
    def step(self, action):
        action = int(action)

        pos_idx = action // self.n_height
        h_idx = action % self.n_height

        if pos_idx in self.occupied_cells:
            return self._get_state(), -5.0, False, False, {}

        x, y = self._cell_to_xy(pos_idx)
        h = self.height_levels[h_idx]

        bs = model.init_base_station(h, (x, y))

        self.base_stations.append(bs)
        self.uav_positions.append((x, y))
        self.uav_heights.append(h)
        self.occupied_cells.add(pos_idx)

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))

        cur_fitness = model.objective_function(
            self.size, self.grid, self.coverage_grid,
            self.users, self.base_stations)

        reward = (cur_fitness - self.prev_fitness) + 0.3 * cur_fitness
        self.prev_fitness = cur_fitness

        self.prev_ucov = ucov
        self.prev_acov = acov
        done = (len(self.uav_positions) >= self.num_uav)

        if done:
            reward += cur_fitness * 0.5

        info = {'ucov': ucov, 'acov': acov, 'num_uav': len(self.uav_positions)}
        return self._get_state(), reward, done, False, info


# DQN 智能体
class DQNAgent:
    def __init__(self, state_size, action_size, hidden=256,
                 lr=1e-3, gamma=0.95,
                 epsilon=1.0, epsilon_min=0.05,
                 buffer_size=100000,
                 batch_size=128,
                 target_update_tau=0.005, device=None):
        self.state_size = state_size
        self.action_size = action_size
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.batch_size = batch_size
        self.tau = target_update_tau
        self.memory = deque(maxlen=buffer_size)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        self.model = self._build_model(hidden).to(self.device)
        self.target_model = self._build_model(hidden).to(self.device)
        self.target_model.load_state_dict(self.model.state_dict())
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.loss_fn = nn.MSELoss()

    # 构建网络
    def _build_model(self, hidden):
        return nn.Sequential(
            nn.Linear(self.state_size, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, self.action_size),
        )

    # 根据训练轮数衰减 epsilon
    def update_epsilon_by_episode(self, ep, total_ep):
        frac = min(1.0, ep / (total_ep * 0.6))
        self.epsilon = 1.0 - frac * (1.0 - self.epsilon_min)

    # 选择动作
    def act(self, state, valid_mask=None, greedy=False):
        if (not greedy) and (np.random.rand() <= self.epsilon):
            if valid_mask is not None and valid_mask.any():
                valid_idx = np.where(valid_mask)[0]
                return int(np.random.choice(valid_idx))
            return np.random.randint(self.action_size)

        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            q = self.model(state_t).cpu().numpy()[0]
        if valid_mask is not None:
            q = np.where(valid_mask, q, -1e9)
        return int(np.argmax(q))

    # 存储经验
    def remember(self, s, a, r, s2, done):
        self.memory.append((s, a, r, s2, done))

    # 经验回放
    def replay(self):
        if len(self.memory) < self.batch_size:
            return None

        minibatch = random.sample(self.memory, self.batch_size)
        states = torch.FloatTensor(np.array([m[0] for m in minibatch])).to(self.device)
        actions = torch.LongTensor([m[1] for m in minibatch]).unsqueeze(1).to(self.device)
        rewards = torch.FloatTensor([m[2] for m in minibatch]).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(np.array([m[3] for m in minibatch])).to(self.device)
        dones = torch.FloatTensor([float(m[4]) for m in minibatch]).unsqueeze(1).to(self.device)

        q_pred = self.model(states).gather(1, actions)

        with torch.no_grad():
            q_next = self.target_model(next_states).max(1, keepdim=True)[0]
            q_target = rewards + self.gamma * q_next * (1.0 - dones)

        loss = self.loss_fn(q_pred, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=10.0)
        self.optimizer.step()

        return float(loss.item())

    # 软更新目标网络
    def soft_update_target(self):
        for tp, p in zip(self.target_model.parameters(), self.model.parameters()):
            tp.data.copy_(self.tau * p.data + (1.0 - self.tau) * tp.data)


# 训练 DQN
def train(num_episodes=300, size=None, num_uav=None, num_users=None,
          grid_res=6, eval_every=50, verbose=True,
          height_levels=(400, 450, 500)):

    env = DeploymentEnv(size=size, num_uav=num_uav, num_users=num_users,
                        grid_res=grid_res,
                        user_move=False,
                        height_levels=height_levels)

    state_size = env.observation_space.shape[0]
    action_size = env.action_space.n
    agent = DQNAgent(state_size, action_size)

    print(f"State dim: {state_size}, Action num: {action_size} "
          f"(pos {env.n_pos} x height {env.n_height})")

    rewards = []
    ucovs = []
    acovs = []
    nfe_history = []
    fgbest_history = []
    current_nfe = 0

    for ep in range(num_episodes):
        agent.update_epsilon_by_episode(ep, num_episodes)

        state, _ = env.reset(seed=None)
        total_reward = 0.0
        done = False
        info = {'ucov': 0.0, 'acov': 0.0}

        while not done:
            valid_mask = env.get_valid_action_mask()
            action = agent.act(state, valid_mask)
            next_state, reward, done, _, info = env.step(action)
            agent.remember(state, action, reward, next_state, done)
            agent.replay()
            agent.soft_update_target()
            state = next_state
            total_reward += reward
            current_nfe += 1

        rewards.append(total_reward)
        ucovs.append(info['ucov'])
        acovs.append(info['acov'])

        f1 = info['acov']
        f2 = info['ucov']
        if env.base_stations:
            f3 = model.calculate_uniformity(env.size, env.grid)
        else:
            f3 = 0.0
        current_fgbest = model.objective_function(
            env.size, env.grid, env.coverage_grid,
            env.users, env.base_stations
        )
        fgbest_history.append(current_fgbest)
        nfe_history.append(current_nfe)

        if verbose and (ep + 1) % 50 == 0:
            print(f"    Episode {ep + 1}/{num_episodes} | "
                  f"reward={total_reward:.4f} | "
                  f"f1={f1:.2%} | f2={f2:.2%} | f3={f3:.4f} | "
                  f"fitness={current_fgbest:.4f} | NFE={current_nfe} | "
                  f"eps={agent.epsilon:.3f}")

        if (ep + 1) % eval_every == 0:
            eval_state, _ = env.reset(seed=None)
            eval_done = False
            eval_info = {'ucov': 0.0, 'acov': 0.0}
            while not eval_done:
                mask = env.get_valid_action_mask()
                a = agent.act(eval_state, mask, greedy=True)
                eval_state, _, eval_done, _, eval_info = env.step(a)
            print(f"  >> Eval @ ep {ep + 1}: f1={eval_info['acov']:.2%}, "
                  f"f2={eval_info['ucov']:.2%}")

    return env, agent, rewards, ucovs, acovs, nfe_history, fgbest_history


def build_result_row(iteration, env, rewards, nfe_history, fgbest_history, total_time):
    final_ucov = model.user_coverage(env.users, env.base_stations)
    model.update_coverage(env.grid, env.coverage_grid,
                          env.base_stations, env.size)
    final_acov = float(np.mean(env.coverage_grid))
    final_f3 = model.calculate_uniformity(env.size, env.grid)
    final_obj = model.objective_function(
        env.size, env.grid, env.coverage_grid,
        env.users, env.base_stations)

    base_station_positions = ";".join(
        [f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
         for bs in env.base_stations])

    result = {
        'Run': iteration,
        'f1 (Global Coverage)': final_acov,
        'f2 (User Coverage)':   final_ucov,
        'f3 (Uniformity)':  final_f3,
        'Fitness':              final_obj,
        'Time (s)':             total_time,
        'Base Station Positions': base_station_positions,
    }
    result[''] = None
    for t, v in enumerate(fgbest_history):
        result[f"fitness {t + 1}"] = v
    result[' '] = None
    for t, v in enumerate(nfe_history):
        result[f"nfe {t + 1}"] = v
    return result


if __name__ == "__main__":
    p = model.canshu()
    NUM_RUNS = 20
    EPISODES_PER_RUN = 2000

    current_dir = os.path.dirname(os.path.abspath(__file__))
    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n Run {i + 1} / {NUM_RUNS} ")
        start_time = time.time()

        env, agent, rewards, ucovs, acovs, nfe_history, fgbest_history = train(
            num_episodes=EPISODES_PER_RUN,
            size=p['size'],
            num_uav=p['num_base_stations'],
            num_users=p['num_users'],
            grid_res=6,
            eval_every=50,
            verbose=True,
            height_levels=(400, 450, 500),
        )

        total_time = time.time() - start_time

        final_ucov = model.user_coverage(env.users, env.base_stations)
        model.update_coverage(env.grid, env.coverage_grid,
                              env.base_stations, env.size)
        final_acov = float(np.mean(env.coverage_grid))
        final_f3 = model.calculate_uniformity(env.size, env.grid)
        final_obj = model.objective_function(
            env.size, env.grid, env.coverage_grid,
            env.users, env.base_stations)

        print(f"  >> Run {i + 1} final: "
              f"f1={final_acov:.2%}, f2={final_ucov:.2%}, "
              f"f3={final_f3:.4f}, Fitness={final_obj:.4f}, "
              f"time={total_time:.1f}s")

        if final_obj > best_obj:
            best_obj = final_obj
            best_f1 = final_acov
            best_f2 = final_ucov
            best_f3 = final_f3
            best_run_id = i + 1

        all_results.append(build_result_row(
            iteration=i + 1, env=env, rewards=rewards,
            nfe_history=nfe_history, fgbest_history=fgbest_history,
            total_time=total_time))

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    excel_path = os.path.join(current_dir, "DQN1_results.xlsx")
    pd.DataFrame(all_results).to_excel(excel_path, index=False)

    print(f"\nExcel saved to {excel_path}")