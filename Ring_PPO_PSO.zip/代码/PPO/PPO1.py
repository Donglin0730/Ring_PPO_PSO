import os
import time
import random
from collections import deque
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import model

# 部署环境
class DeploymentEnv:
    def __init__(self, size=None, num_uav=None, num_users=None,
                 grid_res=6,
                 height_levels=(400, 450, 500),
                 user_move=False):
        params = model.canshu()

        self.size = size if size is not None else params['size']
        self.num_uav = num_uav if num_uav is not None else params['num_base_stations']
        self.num_users = num_users if num_users is not None else params['num_users']

        self.grid_res = grid_res
        self.height_levels = list(height_levels)
        self.n_pos = grid_res * grid_res
        self.n_height = len(self.height_levels)
        self.n_actions = self.n_pos * self.n_height

        self.user_move = user_move
        self.rng = np.random.RandomState()

        # dBm 底噪
        self.grid = np.full((self.size, self.size), model.NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)

        self.users = []
        self.uav_positions = []
        self.uav_heights = []
        self.base_stations = []
        self.occupied_cells = set()
        self.prev_ucov = 0.0
        self.prev_acov = 0.0
        self.prev_fitness = 0.0

    # 网格索引转二维坐标
    def _cell_to_xy(self, cell_idx):
        i = cell_idx // self.grid_res
        j = cell_idx % self.grid_res
        x = (i + 0.5) / self.grid_res * self.size
        y = (j + 0.5) / self.grid_res * self.size
        return x, y

    # 构建状态向量
    def _get_state(self):
        s = np.zeros(self.num_uav * 3, dtype=np.float32)
        for k, (pos, h) in enumerate(zip(self.uav_positions, self.uav_heights)):
            s[k * 3]     = pos[0] / self.size
            s[k * 3 + 1] = pos[1] / self.size
            s[k * 3 + 2] = h / 500.0

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))

        extra = np.array([
            len(self.uav_positions) / self.num_uav,
            ucov, acov,
            1.0 if len(self.uav_positions) == 0 else 0.0,
        ], dtype=np.float32)
        return np.concatenate([s, extra]).astype(np.float32)

    # 重置环境
    def reset(self, seed=None):
        params = model.canshu()
        self.users = model.init_users(
            self.num_users, self.size,
            radius_range=params['user_radius_range'],
            speed_range=params['user_speed_range'],
            seed=None)

        if self.user_move:
            for _ in range(5):
                model.move_users_random_walk(self.users, self.size)

        self.uav_positions = []
        self.base_stations = []
        self.uav_heights = []
        # dBm 底噪
        self.grid = np.full((self.size, self.size), model.NOISE_DBM, dtype=float)
        self.coverage_grid = np.zeros((self.size, self.size), dtype=int)
        self.occupied_cells = set()

        self.prev_ucov = 0.0
        self.prev_acov = 0.0
        self.prev_fitness = 0.0
        return self._get_state()

    # 有效动作掩码
    def get_valid_action_mask(self):
        mask = np.ones(self.n_actions, dtype=bool)
        for c in self.occupied_cells:
            for h_idx in range(self.n_height):
                mask[c * self.n_height + h_idx] = False
        return mask

    # 执行动作
    def step(self, action):
        action = int(action)
        pos_idx = action // self.n_height
        h_idx = action % self.n_height

        if pos_idx in self.occupied_cells:
            return self._get_state(), -5.0, False, {'ucov': 0.0, 'acov': 0.0}

        x, y = self._cell_to_xy(pos_idx)
        h = self.height_levels[h_idx]

        bs = model.init_base_station(h, (x, y))
        self.base_stations.append(bs)
        self.uav_positions.append((x, y))
        self.uav_heights.append(h)
        self.occupied_cells.add(pos_idx)

        ucov = model.user_coverage(self.users, self.base_stations)
        model.update_coverage(self.grid, self.coverage_grid,
                              self.base_stations, self.size)
        acov = float(np.mean(self.coverage_grid))

        cur_fitness = model.objective_function(
            self.size, self.grid, self.coverage_grid,
            self.users, self.base_stations)

        reward = (cur_fitness - self.prev_fitness) + 0.3 * cur_fitness
        self.prev_fitness = cur_fitness

        self.prev_ucov = ucov
        self.prev_acov = acov

        done = (len(self.uav_positions) >= self.num_uav)
        if done:
            reward += cur_fitness * 0.5

        return self._get_state(), reward, done, {'ucov': ucov, 'acov': acov}


# Actor-Critic 网络
class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, hidden=256):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(state_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
        )
        self.actor = nn.Linear(hidden, action_dim)
        self.critic = nn.Linear(hidden, 1)

    def forward(self, x):
        f = self.shared(x)
        logits = self.actor(f)
        value = self.critic(f)
        return logits, value

    # 选择动作
    def get_action(self, state, valid_mask=None, device="cpu"):
        state_t = torch.FloatTensor(state).unsqueeze(0).to(device)
        logits, value = self.forward(state_t)
        if valid_mask is not None:
            mask_t = torch.BoolTensor(valid_mask).to(device)
            logits[0, ~mask_t] = -1e9
        dist = torch.distributions.Categorical(logits=logits)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        return int(action.item()), float(log_prob.item()), float(value.item())

    # 评估动作
    def evaluate_actions(self, states, actions):
        logits, values = self.forward(states)
        dist = torch.distributions.Categorical(logits=logits)
        log_probs = dist.log_prob(actions)
        entropy = dist.entropy()
        return log_probs, values.squeeze(-1), entropy


# PPO 智能体
class PPOAgent:
    def __init__(self, state_dim, action_dim,
                 hidden=256,
                 lr=3e-4,
                 gamma=0.95,
                 lam=0.95,
                 clip_eps=0.2,
                 epochs=4,
                 batch_size=64,
                 entropy_coef=0.01,
                 value_coef=0.5,
                 device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.net = ActorCritic(state_dim, action_dim, hidden).to(self.device)
        self.optimizer = optim.Adam(self.net.parameters(), lr=lr)

        self.gamma = gamma
        self.lam = lam
        self.clip_eps = clip_eps
        self.epochs = epochs
        self.batch_size = batch_size
        self.entropy_coef = entropy_coef
        self.value_coef = value_coef

        self.buffer_s = []
        self.buffer_a = []
        self.buffer_lp = []
        self.buffer_r = []
        self.buffer_v = []
        self.buffer_d = []

    def clear(self):
        self.buffer_s, self.buffer_a, self.buffer_lp = [], [], []
        self.buffer_r, self.buffer_v, self.buffer_d = [], [], []

    def collect_trajectory(self, env, max_steps=25):
        state = env.reset(seed=None)
        done = False
        steps = 0
        while not done and steps < max_steps:
            valid_mask = env.get_valid_action_mask()
            action, log_prob, value = self.net.get_action(
                state, valid_mask, device=self.device)
            next_state, reward, done, _ = env.step(action)
            self.buffer_s.append(state)
            self.buffer_a.append(action)
            self.buffer_lp.append(log_prob)
            self.buffer_r.append(reward)
            self.buffer_v.append(value)
            self.buffer_d.append(done)
            state = next_state
            steps += 1
        with torch.no_grad():
            _, last_v = self.net(
                torch.FloatTensor(state).unsqueeze(0).to(self.device))
        last_v = float(last_v.item())
        return last_v

    # 计算 GAE
    def _compute_gae(self, last_v):
        T = len(self.buffer_r)
        adv = np.zeros(T, dtype=np.float32)
        ret = np.zeros(T, dtype=np.float32)
        gae = 0.0
        for t in reversed(range(T)):
            next_v = last_v if t == T - 1 else self.buffer_v[t + 1]
            non_term = 1.0 - float(self.buffer_d[t])
            delta = self.buffer_r[t] + self.gamma * next_v * non_term - self.buffer_v[t]
            gae = delta + self.gamma * self.lam * non_term * gae
            adv[t] = gae
            ret[t] = gae + self.buffer_v[t]
        return adv, ret

    # 更新网络
    def update(self, last_v):
        if len(self.buffer_r) == 0:
            return

        adv, ret = self._compute_gae(last_v)
        adv = (adv - adv.mean()) / (adv.std() + 1e-8)

        S = torch.FloatTensor(np.array(self.buffer_s)).to(self.device)
        A = torch.LongTensor(np.array(self.buffer_a)).to(self.device)
        LP = torch.FloatTensor(np.array(self.buffer_lp)).to(self.device)
        ADV = torch.FloatTensor(adv).to(self.device)
        RET = torch.FloatTensor(ret).to(self.device)

        T = len(S)
        for _ in range(self.epochs):
            idx = np.random.permutation(T)
            for start in range(0, T, self.batch_size):
                b = idx[start:start + self.batch_size]

                log_probs, values, entropy = self.net.evaluate_actions(S[b], A[b])
                ratio = torch.exp(log_probs - LP[b])

                surr1 = ratio * ADV[b]
                surr2 = torch.clamp(ratio,
                                    1.0 - self.clip_eps,
                                    1.0 + self.clip_eps) * ADV[b]
                actor_loss = -torch.min(surr1, surr2).mean()

                critic_loss = nn.MSELoss()(values, RET[b])

                entropy_loss = -entropy.mean()

                loss = actor_loss + self.value_coef * critic_loss + self.entropy_coef * entropy_loss

                self.optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.net.parameters(), 0.5)
                self.optimizer.step()

    # 保存模型
    def save(self, path):
        torch.save(self.net.state_dict(), path)

    # 加载模型
    def load(self, path):
        try:
            state = torch.load(path, map_location=self.device)
            key = 'shared.0.weight'
            if key in state and state[key].shape[1] != self.net.shared[0].weight.shape[1]:
                print(f"[PPOAgent.load] Dimension mismatch "
                      f"(ckpt={state[key].shape[1]}, model={self.net.shared[0].weight.shape[1]}), "
                      f"skip loading and use random weights.")
                return False
            self.net.load_state_dict(state)
            return True
        except Exception as e:
            print(f"[PPOAgent.load] Load failed: {e}")
            return False


# 训练 PPO
def train_ppo(num_episodes=300, size=None, num_uav=None, num_users=None,
              grid_res=6, eval_every=50, verbose=True,
              height_levels=(400, 450, 500),
              ppo_model_path=None):
    env = DeploymentEnv(size=size, num_uav=num_uav, num_users=num_users,
                        grid_res=grid_res,
                        user_move=False,
                        height_levels=height_levels)

    state_dim = env._get_state().shape[0]
    action_dim = env.n_actions

    agent = PPOAgent(state_dim, action_dim)

    if ppo_model_path and os.path.exists(ppo_model_path):
        ok = agent.load(ppo_model_path)
        if ok:
            print(f"[Init] Loaded PPO from {ppo_model_path}")
        else:
            print(f"[Init] Pretrained model incompatible, using random PPO.")

    print(f"State dim: {state_dim}, Action num: {action_dim} "
          f"(pos {env.n_pos} x height {env.n_height})")

    rewards = []
    ucovs = []
    acovs = []

    nfe_history = []
    fgbest_history = []
    current_nfe = 0

    for ep in range(num_episodes):
        last_v = agent.collect_trajectory(env, max_steps=env.num_uav)
        agent.update(last_v)

        ep_reward = sum(agent.buffer_r)
        rewards.append(ep_reward)
        ucovs.append(env.prev_ucov)
        acovs.append(env.prev_acov)

        current_nfe += len(agent.buffer_r)

        f1 = env.prev_acov
        f2 = env.prev_ucov
        if env.base_stations:
            f3 = model.calculate_uniformity(env.size, env.grid)
        else:
            f3 = 0.0
        current_fgbest = model.objective_function(
            env.size, env.grid, env.coverage_grid,
            env.users, env.base_stations
        )
        fgbest_history.append(current_fgbest)
        nfe_history.append(current_nfe)

        if verbose and (ep + 1) % 50 == 0:
            print(f"    Episode {ep + 1}/{num_episodes} | "
                  f"reward={ep_reward:.4f} | "
                  f"f1={f1:.2%} | f2={f2:.2%} | f3={f3:.4f} | "
                  f"fitness={current_fgbest:.4f} | NFE={current_nfe}")

        agent.clear()

    return env, agent, rewards, ucovs, acovs, nfe_history, fgbest_history

def build_result_row(iteration, env, rewards, nfe_history, fgbest_history, total_time):
    final_ucov = model.user_coverage(env.users, env.base_stations)
    model.update_coverage(env.grid, env.coverage_grid,
                          env.base_stations, env.size)
    final_acov = float(np.mean(env.coverage_grid))
    final_f3 = model.calculate_uniformity(env.size, env.grid)
    final_obj = model.objective_function(
        env.size, env.grid, env.coverage_grid,
        env.users, env.base_stations)

    base_station_positions = ";".join(
        [f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
         for bs in env.base_stations])

    result = {
        'Run': iteration,
        'f1 (Global Coverage)': final_acov,
        'f2 (User Coverage)':   final_ucov,
        'f3 (Uniformity)':  final_f3,
        'Fitness':              final_obj,
        'Time (s)':             total_time,
        'Base Station Positions': base_station_positions,
    }
    result[''] = None
    for t, v in enumerate(fgbest_history):
        result[f"fitness {t + 1}"] = v
    result[' '] = None
    for t, v in enumerate(nfe_history):
        result[f"nfe {t + 1}"] = v
    return result


if __name__ == "__main__":
    p = model.canshu()
    NUM_RUNS = 20
    EPISODES_PER_RUN = 1000

    current_dir = os.path.dirname(os.path.abspath(__file__))

    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n Run {i + 1} / {NUM_RUNS} ")
        start_time = time.time()

        env, agent, rewards, ucovs, acovs, nfe_history, fgbest_history = train_ppo(
            num_episodes=EPISODES_PER_RUN,
            size=p['size'],
            num_uav=p['num_base_stations'],
            num_users=p['num_users'],
            grid_res=6,
            eval_every=50,
            verbose=True,
            height_levels=(400, 450, 500),
            ppo_model_path=None)

        total_time = time.time() - start_time

        final_ucov = model.user_coverage(env.users, env.base_stations)
        model.update_coverage(env.grid, env.coverage_grid,
                              env.base_stations, env.size)
        final_acov = float(np.mean(env.coverage_grid))
        final_f3 = model.calculate_uniformity(env.size, env.grid)
        final_obj = model.objective_function(
            env.size, env.grid, env.coverage_grid,
            env.users, env.base_stations)

        print(f"  >> Run {i + 1} final: "
              f"f1={final_acov:.2%}, f2={final_ucov:.2%}, "
              f"f3={final_f3:.4f}, Fitness={final_obj:.4f}, "
              f"time={total_time:.1f}s")

        if final_obj > best_obj:
            best_obj = final_obj
            best_f1 = final_acov
            best_f2 = final_ucov
            best_f3 = final_f3
            best_run_id = i + 1

        all_results.append(build_result_row(
            iteration=i + 1, env=env, rewards=rewards,
            nfe_history=nfe_history, fgbest_history=fgbest_history,
            total_time=total_time))

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    excel_path = os.path.join(current_dir, "PPO1_results.xlsx")
    pd.DataFrame(all_results).to_excel(excel_path, index=False)

    print(f"\nExcel saved to {excel_path}")