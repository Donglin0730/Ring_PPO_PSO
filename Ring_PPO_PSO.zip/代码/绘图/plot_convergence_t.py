import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from scipy.interpolate import make_interp_spline

BASE_DIR = r"D:\always\Desktop\对比实验\固定时间\随机"

algorithms = [
    ("AHDPSO",       "AHDPSO_results.xlsx",       "s", "tab:blue",   1.5, 2),
    ("AFMPSO",       "AFMPSO_results.xlsx",       "o", "tab:orange", 1.5, 2),
    ("MPSO",         "MPSO_results.xlsx",         "D", "tab:purple", 1.5, 2),
    ("PSO",          "PSO_results.xlsx",          "X", "tab:pink",   1.5, 2),
    ("APSO",         "APSO_results.xlsx",         "h", "tab:olive",  1.5, 2),
    ("SDPSO",        "SDPSO_results.xlsx",        "v", "tab:red",    1.5, 2),
    ("DQN",          "DQN_results.xlsx",          "p", "tab:brown",  1.5, 2),
    ("DERL",         "DERL_results.xlsx",         "P", "tab:gray",   1.5, 2),
    ("PPO",          "PPO_results.xlsx",          "*", "tab:green",  1.5, 2),
    ("Q_learning",   "Q_learning_results.xlsx",   "d", "tab:blue",   1.5, 2),
    ("Ring_PPO_PSO", "Ring_PPO_PSO_results.xlsx", ">", "tab:cyan",   1.5, 10)
]

MARK_TIMES = [10, 100, 200, 300, 400, 500]

def extract_time_curve(file_path):
    df = pd.read_excel(file_path)
    
    time_cols = [c for c in df.columns if str(c).startswith("time_")]
    if not time_cols:
        raise ValueError(f"No time_ columns found in {file_path}")
    
    valid_cols = []
    for c in time_cols:
        try:
            t_val = int(str(c).split('_')[-1])
            if t_val <= 500:
                valid_cols.append((t_val, c))
        except ValueError:
            continue
            
    if not valid_cols:
        raise ValueError(f"No data within 500s in {file_path}")
        
    valid_cols.sort(key=lambda x: x[0])
    sorted_cols = [c for _, c in valid_cols]
    times = np.array([t for t, _ in valid_cols], dtype=float)
    
    curves = df[sorted_cols].values.astype(float)
    mean_curve = np.nanmean(curves, axis=0)
    
    return times, mean_curve

def moving_average(y, window=5):
    if window < 2:
        return y
    padded = np.pad(y, (window//2, window-1-window//2), mode='edge')
    return np.convolve(padded, np.ones(window)/window, mode='valid')

if __name__ == "__main__":
    plt.figure(figsize=(13, 7))

    for name, fname, marker, color, lw, zorder in algorithms:
        if not fname.endswith('.xlsx'):
            continue
            
        file_path = os.path.join(BASE_DIR, fname)
        if not os.path.exists(file_path):
            print(f"[Skipped] File not found: {file_path}")
            continue
            
        try:
            times, mean_curve = extract_time_curve(file_path)

            smoothed_curve = moving_average(mean_curve, window=5)

            if len(times) > 4:
                spline = make_interp_spline(times, smoothed_curve, k=2)
                x_smooth = np.linspace(times.min(), times.max(), 500)
                y_smooth = spline(x_smooth)
            else:
                x_smooth, y_smooth = times, smoothed_curve

            for i in range(1, len(y_smooth)):
                if y_smooth[i] < y_smooth[i-1]:
                    y_smooth[i] = y_smooth[i-1]

            mark_indices = []
            for mt in MARK_TIMES:
                if x_smooth.min() <= mt <= x_smooth.max():
                    idx = (np.abs(x_smooth - mt)).argmin()
                    mark_indices.append(idx)

            plt.plot(
                x_smooth, y_smooth,
                marker=marker,
                markevery=mark_indices,
                markersize=6 if zorder < 5 else 9,
                linewidth=lw,
                color=color,
                label=name,
                zorder=zorder,
                alpha=1.0 if zorder >= 5 else 0.85,
            )
        except Exception as e:
            print(f"[Error] {name}: {e}")

    plt.xlabel("Time (seconds)", fontsize=12)
    plt.ylabel("fgbest", fontsize=12)

    ax = plt.gca()
    ax.xaxis.set_major_formatter(ticker.ScalarFormatter(useOffset=False))
    
    plt.xticks(MARK_TIMES)
    plt.xlim(0, 520) 
    plt.margins(x=0.02, y=0.05)

    plt.legend(fontsize=9, loc="lower right", ncol=3, framealpha=0.9)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.show()