import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

BASE_DIR = r"D:\always\Desktop\对比实验\固定时间\固定"

algorithms = [
    ("AHDPSO",       "AHDPSO_results.xlsx",       "s", "tab:blue",   1.5, 2),
    ("AFMPSO",       "AFMPSO_results.xlsx",       "o", "tab:orange", 1.5, 2),
    ("MPSO",         "MPSO_results.xlsx",         "D", "tab:purple", 1.5, 2),
    ("PSO",          "PSO_results.xlsx",          "X", "tab:pink",   1.5, 2),
    ("APSO",         "APSO_results.xlsx",         "h", "tab:olive",  1.5, 2),
    ("SDPSO",        "SDPSO_results.xlsx",        "v", "tab:red",    1.5, 2),
    ("Ring_PPO_PSO", "Ring_PPO_PSO_results.xlsx", ">", "tab:cyan",   1.5, 10),
]


def extract_fitness_curve(file_path):
    df = pd.read_excel(file_path)
    fit_cols = [c for c in df.columns if str(c).startswith("fitness")]
    if not fit_cols:
        raise ValueError(f"No fitness columns found in {file_path}")
    fit_cols = sorted(fit_cols, key=lambda x: int(str(x).split()[-1]))
    curves = df[fit_cols].values.astype(float)
    mean_curve = np.nanmean(curves, axis=0)
    return mean_curve


def smooth_curve(y, window=31):
    if window <= 1:
        return y
    kernel = np.ones(window) / window
    y_pad = np.pad(y, (window // 2, window - 1 - window // 2), mode='edge')
    return np.convolve(y_pad, kernel, mode='valid')


if __name__ == "__main__":
    x_max = 1200
    x_coordinates = list(range(0, 1201, 200))

    plt.figure(figsize=(13, 7))

    y_min, y_max = 0.58, 0.90

    for name, fname, marker, color, lw, zorder in algorithms:
        file_path = os.path.join(BASE_DIR, fname)

        if not os.path.exists(file_path):
            print(f"[Skipped] File not found: {file_path}")
            continue
        try:
            mean_curve = extract_fitness_curve(file_path)
            y_smooth = smooth_curve(mean_curve, window=31)
            n = len(y_smooth)

            x = np.linspace(0, x_max, n)

            plt.plot(
                x, y_smooth,
                marker=marker,
                markevery=max(1, n // 10),
                markersize=6 if zorder < 5 else 9,
                linewidth=lw,
                color=color,
                label=name,
                zorder=zorder,
                alpha=1.0 if zorder >= 5 else 0.85,
            )
            print(f"{name}: curve length {n}")
        except Exception as e:
            print(f"[Error] {name}: {e}")


    plt.xlabel("NFE (Evaluation Count)", fontsize=12)
    plt.ylabel("fgbest", fontsize=12)

    plt.xlim(0, x_max)
    plt.xticks(x_coordinates, fontsize=10)

    plt.ylim(y_min, y_max)

    plt.yticks(np.arange(y_min, y_max + 0.001, 0.05), fontsize=10)

    plt.margins(x=0, y=0)

    plt.legend(fontsize=10, loc="lower right", ncol=2, framealpha=0.9)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.show()