import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import os
import random

_BASE_TETROMINOES = [
    [(0, 0), (1, 0), (2, 0), (3, 0)],
    [(0, 0), (1, 0), (0, 1), (1, 1)],
    [(0, 0), (1, 0), (2, 0), (2, 1)],
    [(0, 0), (1, 0), (1, 1), (2, 1)],
    [(0, 1), (1, 1), (1, 0), (2, 0)],
    [(0, 0), (1, 0), (1, 1), (2, 1)],
    [(0, 0), (0, 1), (1, 1), (1, 0)],
]

def _normalize_cells(cells):
    min_x = min(c[0] for c in cells)
    min_y = min(c[1] for c in cells)
    return [(x - min_x, y - min_y) for x, y in cells]

def _random_shape(rng, min_blocks=1, max_blocks=4, max_size=5):
    num_blocks = rng.randint(min_blocks, max_blocks)
    cells = set()
    first = rng.choice(_BASE_TETROMINOES)
    for dx, dy in first:
        cells.add((dx, dy))
    for _ in range(num_blocks - 1):
        cand = rng.choice(_BASE_TETROMINOES)
        anchor = rng.choice(list(cells))
        off_x = anchor[0] - rng.randint(0, 3)
        off_y = anchor[1] - rng.randint(0, 3)
        new_cells = [(x + off_x, y + off_y) for x, y in cand]
        merged = cells.union(new_cells)
        max_x = max(c[0] for c in merged)
        min_x = min(c[0] for c in merged)
        max_y = max(c[1] for c in merged)
        min_y = min(c[1] for c in merged)
        if (max_x - min_x + 1) > max_size or (max_y - min_y + 1) > max_size:
            continue
        cells = merged
    return _normalize_cells(list(cells))

def get_buildings(size=50, num_buildings=100):
    rng = random.Random(42)
    occupied_cells = set()
    buildings = []
    attempts = 0
    total_attempts = num_buildings * 100
    while len(buildings) < num_buildings and attempts < total_attempts:
        attempts += 1
        shape = _random_shape(rng, 1, 4, 5)
        max_dx = max(dx for dx, dy in shape)
        max_dy = max(dy for dx, dy in shape)
        gx = rng.randint(0, size - max_dx - 1)
        gy = rng.randint(0, size - max_dy - 1)
        cells = [(gx + dx, gy + dy) for dx, dy in shape]
        if any(c in occupied_cells for c in cells):
            continue
        occupied_cells.update(cells)
        buildings.append({'cells': cells})
    return buildings

def get_radius(height, angle_of_view=55):
    return (height / 100) * np.tan(np.radians(angle_of_view))

def read_users_from_txt(txt_path):
    user_x, user_y = [], []
    if not os.path.exists(txt_path):
        print(f"User file not found: {txt_path}, using default random generation.")
        return None, None
        
    with open(txt_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.replace(',', ' ').split()
            if len(parts) >= 2:
                try:
                    user_x.append(float(parts[0]))
                    user_y.append(float(parts[1]))
                except ValueError:
                    pass
    print(f"Loaded {len(user_x)} user coordinates from {txt_path}.")
    return user_x, user_y

def plot_deployment(excel_path, user_x, user_y, size=50, uav_icon_path=None):
    
    base_name = os.path.basename(excel_path)
    name_no_ext = base_name.replace(".xlsx", "")
    if "_results" in name_no_ext:
        algo_name = name_no_ext.split("_results")[0]
    else:
        algo_name = name_no_ext
    algo_name = algo_name.strip()

    parent_dir = os.path.basename(os.path.dirname(excel_path))
    scale = parent_dir.replace(" ", "_") if parent_dir else "Deploy"

    df = pd.read_excel(excel_path)
    target_pos_str = df['Base Station Positions'].iloc[0] 
    uav_positions = []
    uav_heights = []
    
    if pd.notna(target_pos_str):
        bs_list = target_pos_str.split(';')
        for bs in bs_list:
            coords = bs.strip('()').split(',')
            if len(coords) == 3:
                uav_positions.append((float(coords[0]), float(coords[1])))
                uav_heights.append(float(coords[2]))

    fig, ax = plt.subplots(1, 1, figsize=(8, 8), dpi=150)
    ax.set_facecolor('white')

    # 绘制建筑物
    buildings = get_buildings(size=size, num_buildings=100)
    for b in buildings:
        for (cx, cy) in b['cells']:
            rect = Rectangle((cx, cy), 1, 1,
                             facecolor="#EED366", edgecolor='none',
                             linewidth=0, alpha=0.75, zorder=1) 
            ax.add_patch(rect)

    # 绘制覆盖范围圆
    for (x, y), h in zip(uav_positions, uav_heights):
        r = get_radius(h)
        circle = Circle((x, y), r,
                        facecolor='none', edgecolor='#B0B0B0',
                        linestyle='--', linewidth=1.2, alpha=0.8, zorder=2)
        ax.add_patch(circle)
     
    # 绘制无人机位置
    icon = None
    if uav_icon_path and os.path.exists(uav_icon_path):
        try:
            icon = plt.imread(uav_icon_path)
        except Exception as e:
            print(f"Failed to load UAV icon: {e}, using default marker.")

    if uav_positions:
        if icon is not None:
            for x, y in uav_positions:
                im = OffsetImage(icon, zoom=0.1) 
                ab = AnnotationBbox(im, (x, y), xycoords='data', frameon=False, zorder=3)
                ax.add_artist(ab)
        else:
            ux, uy = zip(*uav_positions)
            ax.scatter(ux, uy, c='#4A90E2', s=60, marker='^', edgecolors='black', linewidths=0.5, zorder=3)

    # 绘制用户位置
    ax.scatter(user_x, user_y, c='#FF2D2D', s=20, zorder=3)

    # 设置坐标轴范围和刻度
    ax.set_xlim(0, size)
    ax.set_ylim(0, size)
    ax.set_xticks(np.arange(0, size + 1, 5))
    ax.set_yticks(np.arange(0, size + 1, 5))
    ax.set_aspect('equal')

    # 保存图片
    save_path = os.path.join(os.path.dirname(excel_path), f"Deployment_{algo_name}_{scale}.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Image saved to: {save_path}")
    
    plt.close(fig)

if __name__ == "__main__":
    
    BASE_DIR = r"D:\always\Desktop\对比实验\20UAV 70users\固定"
    uav_icon_path = r"D:\always\Desktop\uav.png"
    user_txt_file = r"D:\always\Desktop\对比实验\users.txt"
    
    target_files = [
        "DQN_results.xlsx",
        "Q_learning_results.xlsx",
        "DERL_results.xlsx",
        "PPO_results.xlsx",
    ]
    
    user_x, user_y = read_users_from_txt(user_txt_file)
    if user_x is None or len(user_x) == 0:
        np.random.seed(42)
        num_users = 70
        user_x = np.random.uniform(0, 50, num_users)
        user_y = np.random.uniform(0, 50, num_users)

    print(f"Batch generating deployment images in: {BASE_DIR}")

    for filename in target_files:
        excel_path = os.path.join(BASE_DIR, filename)
        
        if not os.path.exists(excel_path):
            print(f"File not found, skipping: {filename}")
            continue
            
        print(f"\nProcessing: {filename}")
        plot_deployment(excel_path, user_x, user_y, size=50, uav_icon_path=uav_icon_path)