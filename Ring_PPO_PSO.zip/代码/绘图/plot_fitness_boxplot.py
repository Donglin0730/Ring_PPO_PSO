import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import matplotlib as mpl
import os

mpl.rcParams['font.family'] = 'Times New Roman'

BASE_DIR = r"D:\always\Desktop\对比实验\20UAV 100users\随机"

if not os.path.exists(BASE_DIR):
    print(f"[Warning] Specified path does not exist: {BASE_DIR}, using script directory.")
    current_dir = os.path.dirname(os.path.abspath(__file__))
else:
    current_dir = BASE_DIR

print(f"Reading data from: {current_dir}")

algo_names = ["AHDPSO", "AFMPSO", "MPSO", "PSO", "SDPSO", "Ring_PPO_PSO"]
excel_files = [os.path.join(current_dir, f"{a}1_results.xlsx") for a in algo_names]

VALUE_COL = 'Fitness'

data = []
for algo, file in zip(algo_names, excel_files):
    if not os.path.exists(file):
        print(f"[Skipped] File not found: {file}")
        continue

    df = pd.read_excel(file)
    if VALUE_COL in df.columns:
        vals = df[VALUE_COL].values
    else:
        vals = df.iloc[:, 1].values
    data.append(np.abs(np.array(vals, dtype=float)))

if not data:
    raise ValueError("No valid data loaded. Please check file existence and column names.")

fig, ax = plt.subplots(figsize=(8, 6))

boxprops    = dict(linestyle='-', linewidth=1, color='black')
whiskerprops= dict(linestyle='-', linewidth=1, color='black')
capprops    = dict(linestyle='-', linewidth=1, color='black')
medianprops = dict(linestyle='-', linewidth=1, color='red')
flierprops  = dict(marker='o', markerfacecolor='green', markersize=5,
                   linestyle='none', markeredgecolor='black')
meanprops   = dict(marker='D', markeredgecolor='black',
                   markerfacecolor='firebrick', markersize=5)

bp = ax.boxplot(data, patch_artist=True, showmeans=True,
                meanprops=meanprops, flierprops=flierprops,
                boxprops=boxprops, whiskerprops=whiskerprops,
                capprops=capprops, medianprops=medianprops)

ax.set_ylabel('Objective Function', rotation=90, labelpad=5)
ax.tick_params(axis='both', labelsize=9)
ax.yaxis.set_minor_locator(plt.MultipleLocator(0.01))

ax.set_ylim(0.65, 0.95)

plot_algos = [algo_names[i] for i, file in enumerate(excel_files) if os.path.exists(file)]
ax.set_xticks(range(1, len(plot_algos) + 1))
ax.set_xticklabels(plot_algos, rotation=15)

for patch, color in zip(bp['boxes'], plt.cm.Pastel1.colors):
    new_color = list(color[:6]) + [0.7]
    patch.set_facecolor(new_color)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_linewidth(1.1)
ax.spines['left'].set_linewidth(1.1)

handles = [bp["means"][0], bp["medians"][0]]
labels  = ['Mean Value', 'Median Line']
if len(bp["fliers"]) > 0 and len(bp["fliers"][0].get_ydata()) > 0:
    handles.insert(1, bp["fliers"][0])
    labels.insert(1, 'Outliers')
ax.legend(handles, labels, frameon=False)

plt.tight_layout()

save_path = os.path.join(current_dir, "Boxplot_Comparison.png")
plt.savefig(save_path, dpi=300)
print(f"\nImage saved to: {save_path}")

plt.show()