import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os
from matplotlib.patches import FancyArrowPatch

plt.rcParams['font.family'] = 'Times New Roman'

BASE_DIR = r"D:\always\Desktop\对比实验\25UAV 70users\固定"  

algorithms = ['AFMPSO', 'AHDPSO', 'APSO', 'MPSO', 'PSO', 'SDPSO', 'DERL', 'DQN', 'Q_learning', 'PPO', 'Ring_PPO_PSO']
fixed_times = []

for algo in algorithms:
    file_path = os.path.join(BASE_DIR, f"{algo}_results.xlsx")
    
    if not os.path.exists(file_path):
        fixed_times.append(0.0) 
        continue
        
    try:
        df = pd.read_excel(file_path)
        if 'Time (s)' in df.columns:
            avg_time = df['Time (s)'].mean()
            fixed_times.append(avg_time)
        else:
            fixed_times.append(0.0)
    except Exception as e:
        fixed_times.append(0.0)

valid_data = [(a, t) for a, t in zip(algorithms, fixed_times) if t > 0]
algo_names = [v[0] for v in valid_data]
times = [v[1] for v in valid_data]

index = np.arange(len(algo_names))
fig, ax = plt.subplots(figsize=(13, 7), dpi=150) 

colors = [
    '#4C72B0', '#DD8452', '#55A868', '#C44E52', '#8172B3', 
    '#937860', '#DA8BC3', '#8C8C8C', '#CCB974', '#64B5CD', '#E17C05'
]
current_colors = colors[:len(algo_names)]

bars = ax.bar(index, times, width=0.6, color=current_colors, edgecolor='black', linewidth=0.7)

# 标签设置
ax.set_xlabel('Algorithms', fontsize=14, fontweight='bold')
ax.set_ylabel('Average Run Time (s)', fontsize=14, fontweight='bold')

ax.set_xticks(index)
ax.set_xticklabels(algo_names, rotation=20, fontsize=12) 
ax.tick_params(axis='x', pad=5) 

# 隐藏右侧和顶部边框
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_linewidth(1.2)
ax.spines['left'].set_linewidth(1.2)

x_min, x_max = ax.get_xlim()
y_min, y_max = ax.get_ylim()

arrow_y_pos = x_max + 0.2 
arrow_x_pos = y_max + (max(times) * 0.02)

y_arrow = FancyArrowPatch((x_min, y_max), (x_min, arrow_x_pos), 
                          arrowstyle='-|>', mutation_scale=10, # 箭头变小
                          color='black', linewidth=1.2, clip_on=False)

x_arrow = FancyArrowPatch((x_max, y_min), (arrow_y_pos, y_min), 
                          arrowstyle='-|>', mutation_scale=10, # 箭头变小
                          color='black', linewidth=1.2, clip_on=False)

ax.add_patch(y_arrow)
ax.add_patch(x_arrow)

for bar in bars:
    yval = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, yval + (max(times)*0.01), f'{yval:.1f}', 
            ha='center', va='bottom', fontsize=11, color='black')

plt.subplots_adjust(bottom=0.2, left=0.1, right=0.95, top=0.95)

save_path = os.path.join(BASE_DIR, "Runtime_Fixed_11Algos_SubtleArrow.png")
plt.savefig(save_path, dpi=300, bbox_inches='tight', pad_inches=0.2)
print(f"图片已保存至: {save_path}")

plt.show()