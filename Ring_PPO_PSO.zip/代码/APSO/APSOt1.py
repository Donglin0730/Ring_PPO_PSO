import os
import time
import random
import numpy as np
import pandas as pd
import model

def run_apso_once(p, max_runtime_seconds=300, verbose=True, record_interval=10):
    size      = p['size']
    num_bs    = p['num_base_stations']
    N         = p['num_particles']

    # 用户随机生成
    users = model.init_users(
        num_users=p['num_users'],
        size=size,
        radius_range=(15, 25),
        speed_range=(1, 3),
        seed=None
    )

    # 初始化粒子群
    x = [[list(np.random.uniform(0, size, 2)) +
          [np.random.uniform(400, 500)]
          for _ in range(num_bs)] for _ in range(N)]
    v = [[[0.0, 0.0, 0.0] for _ in range(num_bs)] for _ in range(N)]
    fitness = [-float('inf')] * N

    w_max, w_min = 0.9, 0.4
    c1_max, c1_min = 2.5, 0.5
    c2_max, c2_min = 0.5, 2.5

    for h in range(N):
        base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                         for bs in x[h]]
        grid = np.full((size, size), model.NOISE_DBM, dtype=float)
        coverage_grid = np.zeros((size, size), dtype=int)
        model.update_coverage(grid, coverage_grid, base_stations, size)
        fitness[h] = model.objective_function(
            size, grid, coverage_grid, users, base_stations)

    Xpbest = [xi.copy() for xi in x]
    fpbest = fitness.copy()
    fgbest = max(fpbest)
    Xgbest = Xpbest[fpbest.index(fgbest)].copy()

    start_time = time.time()

    fitness_history = {}
    next_target_time = record_interval
    t = 0

    if verbose:
        print(f"    [APSO] Start (Time Limit: {max_runtime_seconds}s, Interval: {record_interval}s)")

    while time.time() - start_time < max_runtime_seconds:
        elapsed_time = time.time() - start_time

        # 按时间间隔记录
        while elapsed_time >= next_target_time and next_target_time <= max_runtime_seconds:
            fitness_history[f"time_{next_target_time}"] = fgbest
            if verbose:
                print(f"    [{next_target_time:4d}s] Iter {t:5d} | fgbest = {fgbest:.6f}")
            next_target_time += record_interval

        ratio = elapsed_time / max_runtime_seconds

        f_avg = float(np.mean(fpbest))
        f_best = float(max(fpbest))

        for i in range(N):
            # 自适应惯性权重
            denominator = f_best - f_avg
            if abs(denominator) > 1e-8:
                w = w_min + (w_max - w_min) * (f_best - fpbest[i]) / denominator
            else:
                w = w_max
            w = max(w_min, min(w, w_max))

            # 自适应学习因子
            c1 = c1_max - (c1_max - c1_min) * ratio
            c2 = c2_min + (c2_max - c2_min) * ratio

            r1 = np.random.rand()
            r2 = np.random.rand()
            for j in range(num_bs):
                for k in range(3):
                    v[i][j][k] = (w * v[i][j][k]
                                  + c1 * r1 * (Xpbest[i][j][k] - x[i][j][k])
                                  + c2 * r2 * (Xgbest[j][k] - x[i][j][k]))
                    x[i][j][k] += v[i][j][k]
                # 边界约束
                x[i][j][0] = max(0, min(x[i][j][0], size - 1))
                x[i][j][1] = max(0, min(x[i][j][1], size - 1))
                x[i][j][2] = max(400, min(x[i][j][2], 500))

        # 评估适应度
        for h in range(N):
            base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                             for bs in x[h]]
            grid = np.full((size, size), model.NOISE_DBM, dtype=float)
            coverage_grid = np.zeros((size, size), dtype=int)
            model.update_coverage(grid, coverage_grid, base_stations, size)
            fitness[h] = model.objective_function(
                size, grid, coverage_grid, users, base_stations)

            if fitness[h] > fpbest[h]:
                fpbest[h] = fitness[h]
                Xpbest[h] = [bs.copy() for bs in x[h]]

        if max(fpbest) > fgbest:
            fgbest = max(fpbest)
            Xgbest = Xpbest[fpbest.index(fgbest)].copy()

        t += 1

    # 计算总耗时
    total_time = time.time() - start_time

    # 重新计算最终最优解的各个指标
    grid = np.full((size, size), model.NOISE_DBM, dtype=float)
    coverage_grid = np.zeros((size, size), dtype=int)
    base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                     for bs in Xgbest]
    model.update_coverage(grid, coverage_grid, base_stations, size)

    final_ucov = model.user_coverage(users, base_stations)
    final_acov = float(np.mean(coverage_grid))
    final_f3   = model.calculate_uniformity(size, grid)
    final_obj  = model.objective_function(
        size, grid, coverage_grid, users, base_stations
    )

    return {
        'Xgbest': Xgbest,
        'users': users,
        'base_stations': base_stations,
        'ucov': final_ucov,
        'acov': final_acov,
        'f3':   final_f3,
        'objective': final_obj,
        'fitness_history': fitness_history,
        'total_time': total_time,
        'iterations': t
    }


def build_result_row(iteration, result, fixed_time_columns):
    # 将结果封装为字典
    result_row = {
        'Run': iteration,
        'f1 (Global Coverage)': result['acov'],
        'f2 (User Coverage)':   result['ucov'],
        'f3 (Uniformity)':  result['f3'],
        'Fitness':              result['objective'],
        'Time (s)':             result['total_time'],
        'Iterations':           result['iterations'],
        'Base Station Positions': ";".join(
            [f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
             for bs in result['base_stations']]
        ),
    }
    # 填充固定时间点的历史适应度
    for col in fixed_time_columns:
        result_row[col] = result['fitness_history'].get(col, result['objective'])
    return result_row


if __name__ == "__main__":
    p = model.canshu()
    NUM_RUNS = 20
    # 总运行时间
    MAX_RUNTIME_SECONDS = 500
    # 记录间隔
    RECORD_INTERVAL = 10

    fixed_time_columns = [f"time_{j}" for j in range(RECORD_INTERVAL, MAX_RUNTIME_SECONDS + 1, RECORD_INTERVAL)]

    current_dir = os.path.dirname(os.path.abspath(__file__))
    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n--- Run {i + 1} / {NUM_RUNS} (Time limit: {MAX_RUNTIME_SECONDS}s) ---")
        result = run_apso_once(p, max_runtime_seconds=MAX_RUNTIME_SECONDS,
                               verbose=True, record_interval=RECORD_INTERVAL)

        print(f"  >> Run {i + 1} Final: "
              f"f1={result['acov']:.2%}, f2={result['ucov']:.2%}, "
              f"f3={result['f3']:.4f}, Fitness={result['objective']:.4f}, "
              f"Runtime={result['total_time']:.1f}s")

        if result['objective'] > best_obj:
            best_obj  = result['objective']
            best_f1   = result['acov']
            best_f2   = result['ucov']
            best_f3   = result['f3']
            best_run_id  = i + 1

        all_results.append(build_result_row(i + 1, result, fixed_time_columns))

        excel_path = os.path.join(current_dir, "APSO_results.xlsx")
        try:
            pd.DataFrame(all_results).to_excel(excel_path, index=False)
        except Exception as e:
            print(f"Failed to save Excel: {e}")
            print("Please check if the file is currently open in Excel or WPS and close it before rerunning.")

    print(f"\n Best of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    print(f"\nAll runs completed! Excel saved.")