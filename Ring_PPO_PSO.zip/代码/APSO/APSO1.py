import os
import time
import random
import numpy as np
import pandas as pd
import model

# 从 txt 文件读取用户数据
def run_apso_once(p):
    size      = p['size']
    num_bs    = p['num_base_stations']
    N         = p['num_particles']
    iterators = p['max_iterations']

    # 用户随机生成
    users = model.init_users(
        num_users=p['num_users'],
        size=size,
        radius_range=p['user_radius_range'],
        speed_range=p['user_speed_range'],
        seed=None
    )

    # 初始化粒子群
    x = [[list(np.random.uniform(0, size, 2)) +
          [np.random.uniform(400, 500)]
          for _ in range(num_bs)] for _ in range(N)]
    v = [[[0.0, 0.0, 0.0] for _ in range(num_bs)] for _ in range(N)]
    fitness = [-float('inf')] * N

    w_max, w_min = 0.9, 0.4
    c1_max, c1_min = 2.5, 0.5
    c2_max, c2_min = 0.5, 2.5

    for h in range(N):
        base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                         for bs in x[h]]
        grid = np.full((size, size), model.NOISE_DBM, dtype=float)
        coverage_grid = np.zeros((size, size), dtype=int)
        model.update_coverage(grid, coverage_grid, base_stations, size)
        fitness[h] = model.objective_function(
            size, grid, coverage_grid, users, base_stations)

    Xpbest = [xi.copy() for xi in x]
    fpbest = fitness.copy()
    fgbest = max(fpbest)
    Xgbest = Xpbest[fpbest.index(fgbest)].copy()

    start_time = time.time()
    nfe_history = []
    fgbest_history = []
    current_nfe = N

    for t in range(iterators):
        f_avg = float(np.mean(fpbest))
        f_best = float(max(fpbest))

        for i in range(N):
            # 自适应惯性权重
            if f_best != f_avg:
                w = w_min + (w_max - w_min) * (f_best - fpbest[i]) / (f_best - f_avg)
            else:
                w = w_max
            w = max(w_min, min(w, w_max))

            # 自适应学习因子
            ratio = t / iterators
            c1 = c1_max - (c1_max - c1_min) * ratio
            c2 = c2_min + (c2_max - c2_min) * ratio

            r1 = np.random.rand()
            r2 = np.random.rand()
            for j in range(num_bs):
                for k in range(3):
                    v[i][j][k] = (w * v[i][j][k]
                                  + c1 * r1 * (Xpbest[i][j][k] - x[i][j][k])
                                  + c2 * r2 * (Xgbest[j][k] - x[i][j][k]))
                    x[i][j][k] += v[i][j][k]
                # 边界约束
                x[i][j][0] = max(0, min(x[i][j][0], size - 1))
                x[i][j][1] = max(0, min(x[i][j][1], size - 1))
                x[i][j][2] = max(400, min(x[i][j][2], 500))

        # 评估适应度
        for h in range(N):
            base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                             for bs in x[h]]
            grid = np.full((size, size), model.NOISE_DBM, dtype=float)
            coverage_grid = np.zeros((size, size), dtype=int)
            model.update_coverage(grid, coverage_grid, base_stations, size)
            fitness[h] = model.objective_function(
                size, grid, coverage_grid, users, base_stations)

            if fitness[h] > fpbest[h]:
                fpbest[h] = fitness[h]
                Xpbest[h] = [bs.copy() for bs in x[h]]

        if max(fpbest) > fgbest:
            fgbest = max(fpbest)
            Xgbest = Xpbest[fpbest.index(fgbest)].copy()

        current_nfe += N
        fgbest_history.append(fgbest)
        nfe_history.append(current_nfe)

        if (t + 1) % 50 == 0:
            bs_eval = [model.init_base_station(bs[2], (bs[0], bs[1]))
                       for bs in Xgbest]
            grid_eval = np.full((size, size), model.NOISE_DBM, dtype=float)
            cov_eval = np.zeros((size, size), dtype=int)
            model.update_coverage(grid_eval, cov_eval, bs_eval, size)

            ucov_step = model.user_coverage(users, bs_eval)
            acov_step = float(np.mean(cov_eval))
            f3_step = model.calculate_uniformity(size, grid_eval)
            print(f"    Iter {t+1:5d} | ucov={ucov_step:.2%} | "
                  f"acov={acov_step:.2%} | f3={f3_step:.4f} | "
                  f"fitness={fgbest:.4f} | w={w:.3f} | "
                  f"c1={c1:.2f}, c2={c2:.2f} | NFE={current_nfe}")

    # 计算总耗时
    total_time = time.time() - start_time

    # 重新计算最终最优解的各个指标
    grid = np.full((size, size), model.NOISE_DBM, dtype=float)
    coverage_grid = np.zeros((size, size), dtype=int)
    base_stations = [model.init_base_station(bs[2], (bs[0], bs[1]))
                     for bs in Xgbest]
    model.update_coverage(grid, coverage_grid, base_stations, size)

    final_ucov = model.user_coverage(users, base_stations)
    final_acov = float(np.mean(coverage_grid))
    final_f3   = model.calculate_uniformity(size, grid)
    final_obj  = model.objective_function(
        size, grid, coverage_grid, users, base_stations
    )

    return {
        'Xgbest': Xgbest,
        'users': users,
        'base_stations': base_stations,
        'ucov': final_ucov,
        'acov': final_acov,
        'f3':   final_f3,
        'objective': final_obj,
        'nfe_history': nfe_history,
        'fgbest_history': fgbest_history,
        'total_time': total_time,
    }


def build_result_row(iteration, result):
    # 将结果封装为字典
    result_row = {
        'Run': iteration,
        'f1 (Global Coverage)': result['acov'],
        'f2 (User Coverage)':   result['ucov'],
        'f3 (Uniformity)':  result['f3'],
        'Fitness':              result['objective'],
        'Time (s)':             result['total_time'],
        'Base Station Positions': ";".join(
            [f"({bs['position'][0]:.2f}, {bs['position'][1]:.2f}, {bs['height']:.2f})"
             for bs in result['base_stations']]
        ),
    }
    result_row[''] = None
    for t, v in enumerate(result['fgbest_history']):
        result_row[f"fitness {t + 1}"] = v
    result_row[' '] = None
    for t, v in enumerate(result['nfe_history']):
        result_row[f"nfe {t + 1}"] = v
    return result_row


if __name__ == "__main__":
    p = model.canshu()
    NUM_RUNS = 20
    ITER_PER_RUN = p['max_iterations']

    current_dir = os.path.dirname(os.path.abspath(__file__))
    all_results = []

    best_obj = -float('inf')
    best_f1 = -1.0
    best_f2 = 0.0
    best_f3 = 0.0
    best_run_id = -1

    for i in range(NUM_RUNS):
        print(f"\n Run {i + 1} / {NUM_RUNS} ")
        result = run_apso_once(p)

        print(f"  >> Run {i + 1} final: "
              f"f1={result['acov']:.2%}, f2={result['ucov']:.2%}, "
              f"f3={result['f3']:.4f}, Fitness={result['objective']:.4f}, "
              f"time={result['total_time']:.1f}s")

        if result['objective'] > best_obj:
            best_obj      = result['objective']
            best_f1       = result['acov']
            best_f2       = result['ucov']
            best_f3       = result['f3']
            best_run_id   = i + 1

        all_results.append(build_result_row(i + 1, result))

    print(f"\nBest of {NUM_RUNS} runs ")
    print(f"  Best Run: #{best_run_id}")
    print(f"  Best Fitness      = {best_obj:.4f}")
    print(f"  Best f1 (Global)  = {best_f1:.2%}")
    print(f"  Best f2 (User)    = {best_f2:.2%}")
    print(f"  Best f3 (Uniformity)= {best_f3:.4f}")

    excel_path = os.path.join(current_dir, "APSO1_results.xlsx")
    pd.DataFrame(all_results).to_excel(excel_path, index=False)

    print(f"\nExcel saved to {excel_path}")